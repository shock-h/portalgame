<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com
 */
 
/**
 * Get Class
 */
 
class Get {
    private $name;
    private $data;
    function system($name) {
        global $db, $secure;
        $find = $db->query("SELECT value FROM settings WHERE name = '$name' LIMIT 1");
        $get_data = $find->fetch_assoc();
        return $get_data["value"];
    }
    function game($id, $sc, $cache = "cache/games/") {
        global $db, $secure;
        if ($sc == 1) {
            if (file_exists($cache . $secure->hashed($id) . ".cache")) {
                return json_decode(base64_decode(file_get_contents($cache . $secure->hashed($id) . ".cache")), true);
            } else {
                $fetch_game = $db->query("SELECT id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays FROM games WHERE id = $id LIMIT 1");
                file_put_contents($cache . $secure->hashed($id) . ".cache", base64_encode(json_encode($fetch_game->fetch_assoc())));
                return json_decode(base64_decode(file_get_contents($cache . $secure->hashed($id) . ".cache")), true);
            }
        } else {
            $fetch_game = $db->query("SELECT id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays FROM games WHERE id = $id LIMIT 1");
            return $fetch_game->fetch_assoc();
        }
    }
    function category($data){
    	 global $db;
    	 $get_cat = $db->query("SELECT name FROM categories WHERE id = $data LIMIT 1");
    	 if($get_cat->num_rows > 0){
    	 	 $cat_data = $get_cat->fetch_assoc();
    	 	 return $cat_data["name"]; 
    	 } else {
    	 	 return "Unknown";
    	 }     	
    }
    function user($id, $data) {
        global $db;
        $find = $db->query("SELECT $data FROM users WHERE id = $id LIMIT 1");
        $get_data = $find->fetch_assoc();
        return $get_data[$data];
    }
    function userData($get, $lang, $path = "cache/users/"){
    	global $db, $secure;
    	if (isset($_SESSION["logged"])) {
    		if (file_exists($path . $secure->hashed($_SESSION["logged"]) . ".cache")) {
    			$user = json_decode(base64_decode(file_get_contents($path . $secure->hashed($_SESSION["logged"]) . ".cache")), true);
        $user["status"] = $get->user($_SESSION["logged"], "status");        
       } else {
       	$get_user = $db->query("SELECT id, position, username, avatar, cover, exp, fullname, website, quote, fb_link, gp_link, tw_link, about, robohash, ref, registered, status  FROM users WHERE id = ".$_SESSION["logged"]." LIMIT 1");
       	$user = $get_user->fetch_array();   	     
       	if ($get->system("smart_cache") == 1) {
       		file_put_contents($path . $secure->hashed($_SESSION["logged"]) . ".cache", base64_encode(json_encode($user)));       		
       	}       	
       }
       $_SESSION["status"] = time();
      } else {
      	$user = array("id" => 0, "position" => 0, "username" => $lang["username_guest"]);
     } 
     if (isset($_SESSION["lang_code"])) {
     	$find_lang = $db->query("SELECT rtl FROM languages WHERE code = '" . $_SESSION["lang_code"] . "' LIMIT 1");
     	$get_lang = $find_lang->fetch_assoc();
     	$_SESSION["lang_rtl"] = $get_lang["rtl"]; 	     	
     }     
     return $user;   	
    }
	function avatar($id, $username, $robohash, $type, $class, $get) {
		global $db;
    	$site_url = $get->system("site_url");
    	$template = $get->system("template");
		$get_user = $db->query("SELECT oauth_name, oauth_id FROM users WHERE username = '$username' LIMIT 1");
		$udata = $get_user->fetch_assoc();
		if(!empty($udata["oauth_id"]) && $udata["oauth_name"] == "facebook"){
			$avatar = "<img src='".$site_url."/templates/".$template."/assets/images/loader.gif' data-src='http://graph.facebook.com/".$udata["oauth_id"]."/picture?type=large&redirect=true&width=500&height=500' class='lazy-avatar b-radius " . $class . "'>";			
		} else {
			if ($type == 3) {
				$avatar = "<img src='".$site_url."/templates/".$template."/assets/images/loader.gif' data-src='https://api.adorable.io/avatar/150/" . md5($site_url.$username.$id) . ".png' class='lazy-avatar b-radius " . $class . "'>";
			} else if ($type == "2") {
				$avatar = "<img src='".$site_url."/templates/".$template."/assets/images/loader.gif' data-src='https://robohash.org/" . md5($site_url.$username.$id) . ".png?bgset=any&set=set" . $robohash . "&size=150x150' class='lazy-avatar b-radius " . $class . "'>";
			} else {
				$avatar = "<img data-name='" . $username . "' data-width='150' data-height='150' data-font-size='70' class='avatar  b-radius " . $class . "'>";
			}
		}
        return $avatar;
    }
	function robohash() {
        $array = array(1, 2, 3, 3, 2, 1, 2, 1, 3, 3, 1, 2);
        shuffle($array);
        return $array[rand(0, 10)];
    }
    function gameAuthor($id) {
        global $db;
        $find = $db->query("SELECT username FROM users WHERE id = $id LIMIT 1");
        if ($find->num_rows > 0) {
            $user_data = $find->fetch_assoc();
            return $user_data["username"];
        } else {
            return "Unknown";
        }
    }
    function position($position, $lang) {
        if ($position == 1) {
            return "<span class='admin_pos'><i class='fa fa-user'></i> ".$lang["position_admin"]."</span>";
        }
        if ($position == 2) {
            return "<span class='mod_pos'><i class='fa fa-user'></i> ".$lang["position_moderator"]."</span>";
        }
        if ($position == 3) {
            return "<span class='author_pos'><i class='fa fa-user'></i> ".$lang["position_author"]."</span>";
        }
        if ($position == 4) {
            return "<i class='fa fa-user'></i> ".$lang["position_member"];
        }
        if (!in_array($position, array(1, 2, 3, 4))) {
            return "<i class='fa fa-user'></i> ".$lang["position_guest"];
        }
    }
    function thumb($thumb, $name, $secure, $get){
			if ($secure->isUrl($thumb)) {
				$thumb = '<img src="' . $get->system("site_url") . '/templates/' . $get->system("template") . '/assets/images/loader.gif" data-src="' . $thumb . '" alt="' . $name . '">';
			} else {
				$thumb = '<img src="' . $get->system("site_url") . '/templates/' . $get->system("template") . '/assets/images/loader.gif" data-src="' . $get->system("site_url") . '/uploads/thumbs/' . $thumb . '" alt="' . $name . '">';
			}  
        return $thumb;  	
    }
    function language($default_lang = "en", $path = "languages/"){
    	global $db;
    	if (!file_exists($path . $default_lang . ".lang")) {
    		die("Critical Error! Default language file not found!");    		
    	} else {
    		if (isset($_SESSION["logged"])) {
    			$find = $db->query("SELECT language FROM users WHERE id = '" . $_SESSION["logged"] . "' LIMIT 1");
    			$data = $find->fetch_assoc();
    			if (!empty($data["language"])) {
    				$lang_code = $data["language"];
    				$check_lang = $db->query("SELECT code FROM languages WHERE code = '$lang_code' LIMIT 1");
    				if ($check_lang->num_rows > 0) {
    					$lang_data = $check_lang->fetch_assoc();
    					$lang = json_decode(file_get_contents($path . $lang_data["code"] . ".lang"), true);
    					$_SESSION["lang_code"] = $lang_data["code"];    					
    				} else if (isset($_SESSION["lang"])) {
    					$lang = json_decode(file_get_contents($path . $_SESSION["lang"] . ".lang"), true);
    					$_SESSION["lang_code"] = $_SESSION["lang"];    					
    				} else {
    					$lang = json_decode(file_get_contents($path . $default_lang . ".lang"), true);
    					$_SESSION["lang_code"] = $default_lang;					
    				}    				
    			} else {
    				if (isset($_SESSION["lang"]) && file_exists($path . $_SESSION["lang"] . ".lang")) {
    					$lang = json_decode(file_get_contents($path . $_SESSION["lang"] . ".lang"), true);
    					$_SESSION["lang_code"] = $_SESSION["lang"];    					
    				} else {
    					$lang = json_decode(file_get_contents($path . $default_lang . ".lang"), true);
    					$_SESSION["lang_code"] = $default_lang;    					
    				}    				
    			}    			
    		} else {
    			if (isset($_SESSION["lang"]) && file_exists($path . $_SESSION["lang"] . ".lang")) {
    				$lang = json_decode(file_get_contents($path . $_SESSION["lang"] . ".lang"), true);
    				$_SESSION["lang_code"] = $_SESSION["lang"];    				
    			} else {
    				$lang = json_decode(file_get_contents($path . $default_lang . ".lang"), true);
    				$_SESSION["lang_code"] = $default_lang; 				
    			}    			
    		}    		
    	}    	
    	return $lang;
    }
    function gameStars($data, $type = "full") {
		if($type == "full"){
			if ($data >= 0) {
				$stars = "
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 100) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 250) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star-half-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 600) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 800) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star-half-o'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 1200) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 1800) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star-half-o'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 2400) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star-o'></i>  			  			  			 
				";
			}
			if ($data >= 3400) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star-half-o'></i>  			  			  			 
				";
			}
			if ($data >= 5000) {
				$stars = "
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>
				<i class='fa fa-star'></i>  			  			  			 
				";
			}
		} else {
			if ($data >= 0) {
				$stars = 0;
			}
			if ($data >= 100) {
				$stars = 1;
			}
			if ($data >= 250) {
				$stars = 1.5;
			}
			if ($data >= 600) {
				$stars = 2;
			}
			if ($data >= 800) {
				$stars = 2.5;
			}
			if ($data >= 1200) {
				$stars = 3;
			}
			if ($data >= 1800) {
				$stars = 3.5;
			}
			if ($data >= 2400) {
				$stars = 4;
			}
			if ($data >= 3400) {
				$stars = 4.5;
			}
			if ($data >= 5000) {
				$stars = 5;
			}
		}
        return $stars;
    }
    function userRank($data, $data_exp, $lang) {
        if ($data >= 0) {
            $rank = $lang["rank_1"];
        }
        if ($data >= 20 * $data_exp) {
            $rank = $lang["rank_2"];
        }
        if ($data >= 50 * $data_exp) {
            $rank = $lang["rank_3"];
        }
        if ($data >= 70 * $data_exp) {
            $rank = $lang["rank_4"];
        }
        if ($data >= 100 * $data_exp) {
            $rank = $lang["rank_5"];
        }
        if ($data >= 130 * $data_exp) {
            $rank = $lang["rank_6"];
        }
        if ($data >= 150 * $data_exp) {
            $rank = $lang["rank_7"];
        }
        if ($data >= 250 * $data_exp) {
            $rank = $lang["rank_8"];
        }
        if ($data >= 300 * $data_exp) {
            $rank = $lang["rank_9"];
        }
        if ($data >= 500 * $data_exp) {
            $rank = $lang["rank_10"];
        }
        return $rank;
    }
    
    function profileStatus($data, $lang){
    	if ($data == 1) {
    		$status = '<span class="btn btn-sm btn-success profile-btn" title="' . $lang["status_title"] . '"><i class="fa fa-user"></i> ' . $lang["parts_online_profile"] . '</span>';    		
    	} else {
    		$status = '<span class="btn btn-sm btn-danger profile-btn" title="' . $lang["status_title"] . '"><i class="fa fa-user"></i> ' . $lang["parts_offline_profile"] . '</span>';    		
    	} 
    	return $status;   	
    }
    
    function profileFullname($username, $fn){
    	if (empty($fn)) {
    		$fullname = ucfirst($username);    		
    	} else {
    		$fullname = $fn;    		
    	}    	
    	return $fullname;
    }
    
    function profileWebsite($data, $lang){
    	if (empty($data)) {
    		$website = $lang["parts_nowebsite_profile"];    		
    	} else {
    		$website = $data;    		
    	}  
    	return $website;  	
    }
    
    function profileQuote($data, $lang){
    	if (empty($data)) {
    		$quote = $lang["parts_quote_profile"];    		
    	} else {
    		$quote = $data;
     }
     return $quote;
    }
    
    function profileAbout($data, $lang){
    	if (empty($data)) {
    		$about = $lang["parts_about_profile"];    		
    	} else {
    		$about = $data;   		
    	}    	
    	return $about;
    }
    
    function profileCover($data, $site_url){
    	if (!empty($data)) {
    		$cover = 'style="background: url(' . $site_url . '/uploads/covers/' . $data . ') no-repeat center; background-size: cover;"';    		
    	} else {
    		$cover = NULL;    		
    	} 
    	return $cover;
    }
    
    function userPosts($data){
    	global $db;
    	$get_posts = $db->query("SELECT id FROM games WHERE uid = " . $data);
    	$posts = $get_posts->num_rows;
    	return $posts;
    }
    
    function userComments($data){
    	global $db;
    	$get_comments = $db->query("SELECT id FROM comments WHERE uid = " . $data);
    	$comments = $get_comments->num_rows;    	    	
    	return $comments;
    }
    
    function gameThumb($thumb, $site_url){
    	global $secure;
    	if(!$secure->isUrl($thumb)){
    		return $site_url . "/uploads/thumbs/" . $thumb;
    	} else {
    		return $thumb;
    	}
    }
}
/* End */
?>