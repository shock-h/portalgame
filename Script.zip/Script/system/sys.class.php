<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com>
 */
 
/**
 * System Class
 */
 
class System {
    private $name;
    private $data;
    private $site_url;
    private $length;
    private $id;
    private $username;
    private $robohash;
    private $class;
	
    function saveSystem($name, $data) {
        global $db;
        $data = $db->real_escape_string($data);
        $save = $db->query("UPDATE settings SET value = '$data' WHERE name = '$name' LIMIT 1");
        if ($save) {
            return true;
        } else {
            return false;
        }
    }
    function go($data) {
        header("location: " . $data);
    }
    function shareEncode($data) {
        return urlencode($data);
    }    
    function clearCache($type, $path, $name = NULL) {
        if ($type == "game") {
            @unlink($path . $name . ".cache");
        } else if ($type == "user") {
            @unlink($path . $name . ".cache");
        } 
        return true;
    }    
    function gamecenter($data = NULL){
    	$ch = curl_init();
		$url = "http://gamecenter.noriellecruz.com/" . $data;
    	curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    	curl_setopt($ch, CURLOPT_HEADER, 0);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    	curl_setopt($ch, CURLOPT_URL, $url);
    	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    	$data = curl_exec($ch);
    	curl_close($ch);
    	return $data;
    }    
    function timeAgo($date, $lang, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($date);
        $diff = $now->diff($ago);
        $diff->w = floor($diff->d / 7);
        $diff->d-= $diff->w * 7;
        $string = array('y' => $lang["timeago_year"], 'm' => $lang["timeago_month"], 'w' => $lang["timeago_week"], 'd' => $lang["timeago_day"], 'h' => $lang["timeago_hour"], 'i' => $lang["timeago_minute"], 's' => $lang["timeago_second"]);
        foreach ($string as $k => & $v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? $lang["timeago_s"] : '');
            } else {
                unset($string[$k]);
            }
        }
        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' '.$lang["timeago_ago"] : $lang["timeago_now"];
    }
    function smileyCompile($data, $site_url) {
        $smiles = array(
        ':)' => 'smile.png', 
        ':(' => 'sad.png', 
		':happy:' => 'smile.png', 
        ':sad:' => 'sad.png',
		':heart:' => 'heart.png',
        ':angry:' => 'angry.png', 
        ':cry:' => 'cwy.png', 
		':angel:' => 'angel.png',
        ':devil:' => 'devil.png', 
        ':cool:' => 'cool.png', 
        ':grin:' => 'grin.png', 
        ':shocked:' => 'shocked.png',
		':alien:' => 'alien.png',
		':ninja:' => 'ninja.png',
		':wink:' => 'wink.png',
		':lost:' => 'lost.png'
        );
        foreach ($smiles as $key => $img) {
            $data = str_replace($key, '<img src="' . $site_url . '/system/assets/emoticons/' . $img . '" class="emoticon">', $data);
        }
        return $data;
    }
    function chatFilter($message, $filter) {
        $words = array(explode(",", str_replace(" ", "", $filter)));
        foreach ($words as $bad) {
            $data = str_replace($bad, "*****", $message);
        }
        return $data;
    }
    function limitString($data, $length) {
		if(strlen($data) <= $length){
			return $data;
		} else {
			return substr($data, 0, $length) . "...";
		}
    }
}

/* End */
?>