<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com>
 */

/**
 * Start Session
 */

session_start();

/**
 * Require Database
 */

require '../database.php';

/**
 * Require System Class
 */

require '../sys.class.php';
$sys = new System;

/**
 * Require Security Class
 */

require '../security.class.php';
$secure = new Security;

/**
 * Require Get Class
 */

require '../get.class.php';
$get = new Get;

/**
 * Language Variable
 */

$lang = $get->language($get->system("default_lang"), "../../languages/");

/**
 * User Data
 */

$user = $get->userData($get, $lang, "../../cache/users/");

/**
 * Process Requests
 */

if ($get->system("enable_chat") == 1 && isset($_POST["message"]) && strlen($_POST["message"]) > 0) {
    if ($_POST["message"] == "/clear") {
        if ($user["position"] == 1 OR $user["position"] == 2) {
            die($db->query("TRUNCATE shoutbox"));
        } else {
            $message = $secure->purify($sys->chatFilter($_POST["message"], $get->system("chat_filter")));
        }
    } else {
        $raw_m = explode(" ", $_POST["message"]);
        if ($user["position"] == 1 OR $user["position"] == 2) {
            if ($raw_m[0] == "/warn" && !empty($raw_m[1])) {
				$username = $secure->purify($raw_m[1]);
				$get_user = $db->query("SELECT id FROM users WHERE username = '$username' LIMIT 1");
				if($get_user->num_rows > 0){
					$message = "Warning for " . ucfirst($secure->purify($sys->chatFilter($username, $get->system("chat_filter")))) . "! Please stop violating the rules!";
				} else {
						$message = "Command Error! User not found!";
				}
            } else if ($raw_m[0] == "/ban" && !empty($raw_m[1])) {
				$username = $secure->purify($raw_m[1]);
                $get_user = $db->query("SELECT id FROM users WHERE username = '$username' LIMIT 1");
				if($get_user->num_rows > 0){
					$udata = $get_user->fetch_assoc();
					if($udata["id"] == 1){
						$message = "Command Error!";
					} else {
						$ban_user = $db->query("UPDATE users SET banned = 1 WHERE username = '$username' LIMIT 1");
						if($ban_user){
							$message = "<strong>" . ucfirst($secure->purify($sys->chatFilter($username, $get->system("chat_filter")))) . "</strong> was banned!";
						} else {
							$message = "Command Error!";
						}
					}
				} else {
						$message = "Command Error! User not found!";
				}
            } else if ($raw_m[0] == "/unban" && !empty($raw_m[1])) {
				$username = $secure->purify($raw_m[1]);
                $get_user = $db->query("SELECT id FROM users WHERE username = '$username' LIMIT 1");
				if($get_user->num_rows > 0){
					$udata = $get_user->fetch_assoc();
					if($udata["id"] == 1){
						$message = "Command Error!";
					} else {
						$unban_user = $db->query("UPDATE users SET banned = 0 WHERE username = '$username' LIMIT 1");
						if($unban_user){
							$message = "Ban for <strong>" . ucfirst($secure->purify($sys->chatFilter($username, $get->system("chat_filter")))) . "</strong> has been removed!";
						} else {
							$message = "Command Error!";
						}
					}
				} else {
						$message = "Command Error! User not found!";
				}
            } else {
                $message = $secure->purify($sys->chatFilter($_POST["message"], $get->system("chat_filter")));
            }
        } else {
            $message = $secure->purify($sys->chatFilter($_POST["message"], $get->system("chat_filter")));
        }
    }
    if (!empty($message) && strlen($message) > 1 && $db->query("INSERT INTO shoutbox (uid, message) VALUES (" . $user["id"] . ",'$message');")) {
        if ($user["id"] == 0) {
            if (!isset($_SESSION["robohash"])) {
                $_SESSION["robohash"] = $get->robohash();
            }
            $avatar = $get->avatar($secure->hashed($user["id"]), "Guest_" . $_SERVER["REMOTE_ADDR"], $_SESSION["robohash"], $get->system("default_avatar"), "chat-avatar ", $get);
            die('<div class="shout_msg">
				<span class="pull-left">' . $avatar . '</span>
				<span class="username">'.$user["username"].' (' . $_SERVER["REMOTE_ADDR"] . ')</span>
				<span class="message">' . $sys->smileyCompile($message, $get->system("site_url")) . '</span>
				</div>');
        } else {
            if (!empty($user["avatar"])) {
                $avatar = '<img src="'.$get->system("site_url").'/templates/'.$get->system("template").'/assets/images/loader.gif" data-src="' . $get->system("site_url") . '/uploads/avatars/' . $user["avatar"] . '" class="lazy-avatar chat-avatar">';
            } else {
                $avatar = $get->avatar($secure->hashed($user["id"]), $user["username"], $user["robohash"], $get->system("default_avatar"), "chat-avatar ", $get);
            }
            if($user["position"] == 1){
            	 $pos_class = " admin_pos";
            } else if($user["position"] == 2){
            	 $pos_class = " mod_pos";
            } else if($user["position"] == 3){
            	 $pos_class = " author_pos";
            } else {
            	 $pos_class = NULL;
            }
            die('<div class="shout_msg">
				<span class="pull-left"><a href="'.$get->system("site_url").'/user/'.$user["username"].'">' . $avatar . '</a></span>
				<span class="username'.$pos_class.'"><a href="'.$get->system("site_url").'/user/'.$user["username"].'">' . ucfirst($user["username"]) . '</a></span> 
				<span class="message">' . $sys->smileyCompile($message, $get->system("site_url")) . '</span>
				</div>');
        }
    }
    $db->query("DELETE FROM shoutbox WHERE id NOT IN (SELECT * FROM (SELECT id FROM shoutbox ORDER BY id DESC LIMIT 0, 10) as sb)");
} else if (isset($_POST["get"]) && $get->system("enable_chat") == 1 && $_POST["get"] == 1) {
    if ($get->system("guest_chat") == 0 && !isset($_SESSION["logged"])) {
        die("error");
    }
    $shouts = $db->query("SELECT uid, message, time FROM (select * from shoutbox ORDER BY id DESC LIMIT 10) shoutbox ORDER BY shoutbox.id ASC");
    if ($shouts->num_rows > 0) {
        while ($row = $shouts->fetch_assoc()) {
            $time = $sys->timeAgo($row["time"], $lang);
            if ($row["uid"] == 0) {
                if (!isset($_SESSION["robohash"])) {
                    $_SESSION["robohash"] = $get->robohash();
                }
                $avatar = $get->avatar($secure->hashed($user["id"]), "Guest_" . $_SERVER["REMOTE_ADDR"], $_SESSION["robohash"], $get->system("default_avatar"), "chat-avatar ", $get);
                echo '<div class="shout_msg">
					<span class="pull-left">' . $avatar . '</span>
					<span class="pull-right">' . $time . '</span>
					<span class="username">'.$user["username"].' (' . $_SERVER["REMOTE_ADDR"] . ')</span> 
					<span class="message">' . $sys->smileyCompile($row["message"], $get->system("site_url")) . '</span>
					</div>';
            } else {
                $find_user = $db->query("SELECT id, position, username, avatar, robohash FROM users WHERE id = " . $row["uid"] . " LIMIT 1");
                if ($find_user->num_rows > 0) {
                    $udata = $find_user->fetch_assoc();
                    if (!empty($udata["avatar"])) {
                        $avatar = '<img src="'.$get->system("site_url").'/templates/'.$get->system("template").'/assets/images/loader.gif" data-src="' . $get->system("site_url") . '/uploads/avatars/' . $udata["avatar"] . '" class="lazy-avatar chat-avatar">';
                    } else {
                        $avatar = $get->avatar($secure->hashed($udata["id"]), $udata["username"], $udata["robohash"], $get->system("default_avatar"), "chat-avatar ", $get);
                    }
                    if($udata["position"] == 1){
                    	$pos_class = " admin_pos";                    	
                    } else if($udata["position"] == 2){
                    	$pos_class = " mod_pos";                    	
                    } else if($udata["position"] == 3){
                    	$pos_class = " author_pos";                    	
                    } else {
                    	$pos_class = NULL;                    	
                    }                    
                    echo '<div class="shout_msg">
						<span class="pull-left"><a href="'.$get->system("site_url").'/user/'.$udata["username"].'">' . $avatar . '</a></span>
						<span class="pull-right">' . $time . '</span>
						<span class="username'.$pos_class.'"><a href="'.$get->system("site_url").'/user/'.$udata["username"].'">' . ucfirst($udata["username"]) . '</a></span> 
						<span class="message">' . $sys->smileyCompile($row["message"], $get->system("site_url")) . '</span>
						</div>';
                }
            }
        }
    } else {
        die('<div class="alert alert-warning text-center">
			<i class="fa fa-exclamation-circle"></i> ' . $lang["error_noshouts"] . '
			</div>');
    }
} else {
    die("error");
}
/* End */
?>