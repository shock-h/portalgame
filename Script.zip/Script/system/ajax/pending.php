<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com>
 */

/**
 * Start Session
 */

session_start();

/**
 * Require Database
 */

require '../database.php';

/**
 * System Class
 */

require '../sys.class.php';
$sys = new System;

/**
 * Get Class
 */

require '../get.class.php';
$get = new Get;

/**
 * Security Class
 */

require '../security.class.php';
$secure = new Security;

/**
 * Process Requests
 */

$user = $get->userData($get, "../../cache/users/");

if (isset($_GET["do"], $_SESSION["logged"], $_GET["id"], $_GET["aid"]) && $_GET["do"] == "publish" && $secure->isNumber($_GET["id"]) && $secure->isNumber($_GET["aid"])) {
    if ($user["position"] == 1 OR $user["position"] == 2) {
        $id = $secure->purify($_GET["id"]);
        $aid = $secure->purify($_GET["aid"]);
        $publish = $db->query("UPDATE games SET status = 1 WHERE id = $id LIMIT 1");
        if ($publish) {
            $find_user = $db->query("SELECT exp FROM users WHERE id = $aid LIMIT 1");
            $udata = $find_user->fetch_assoc();
            $new_exp = $udata["exp"] + $get->system("exp_addgame");
            $db->query("UPDATE users SET exp = $new_exp WHERE id = $aid LIMIT 1");
			$sys->clearCache("game", "../../../cache/games/", $secure->hashed($id));
            die("success");
        } else {
            die("error");
        }
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $_GET["do"] == "delete" && $secure->isNumber($_GET["id"])) {
    if ($user["position"] == 1 OR $user["position"] == 2) {
        $id = $secure->purify($_GET["id"]);
        $delete = $db->query("DELETE FROM games WHERE id = $id LIMIT 1");
        if ($delete) {
			$sys->clearCache("game", "../../../cache/games/", $secure->hashed($id));
            die("success");
        } else {
            die("error");
        }
    } else {
        die("error");
    }
} else {
    die("error");
}
/* End */
?>