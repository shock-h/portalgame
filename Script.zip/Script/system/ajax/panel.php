<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com>
 */

/**
 * Start Session
 */

session_start();

/**
 * Require Database
 */

require '../database.php';

/**
 * System Class
 */

require '../sys.class.php';
$sys = new System;

/**
 * Security Class
 */

require '../security.class.php';
$secure = new Security;

/**
 * Get Class
 */

require '../get.class.php';
$get = new Get;

/**
 * Password Function
 */

require '../external/password.php';

/**
 * Language Variable
 */

$lang = $get->language($get->system("default_lang"), "../../languages/");

/**
 * Process Requests
 */

$user = $get->userData($get, $lang, "../../cache/users/");

if (isset($_SESSION["logged"], $_GET["do"], $_POST["site_name"], $_POST["site_url"], $_POST["tags"], $_POST["description"], $_POST["analytics"], $_POST["smart_cache"], $_POST["cdn_assets"], $_POST["submissions"], $_POST["template"], $_POST["template_color"], $_POST["game_tooltip"], $_POST["anti_adblock"], $_POST["landscape_mode"], $_POST["fullscreen"], $_POST["featured"], $_POST["footer_links"], $_POST["default_avatar"], $_POST["default_lang"]) && $user["position"] == 1 && $_GET["do"] == "system") {
    $site_name = $secure->purify($_POST["site_name"]);
    $site_url = $secure->purify($_POST["site_url"]);
    $tags = $secure->purify($_POST["tags"]);
    $description = $secure->purify($_POST["description"]);
    $analytics = $secure->purify($_POST["analytics"]);    
    $smart_cache = $secure->purify($_POST["smart_cache"]);
    $cdn_assets = $secure->purify($_POST["cdn_assets"]);
    $submissions = $secure->purify($_POST["submissions"]);       
    $template = $secure->purify($_POST["template"]);    
    $template_color = $secure->purify($_POST["template_color"]);
    $game_tooltip = $secure->purify($_POST["game_tooltip"]);  	
    $anti_adblock = $secure->purify($_POST["anti_adblock"]);    
    $landscape_mode = $secure->purify($_POST["landscape_mode"]);
    $fullscreen = $secure->purify($_POST["fullscreen"]);
    $featured = $secure->purify($_POST["featured"]);
    $footer_links = $secure->purify($_POST["footer_links"]);    
    $default_avatar = $secure->purify($_POST["default_avatar"]);
    $default_lang = $secure->purify($_POST["default_lang"]);
    
    if (!$secure->isNumber($smart_cache) || !$secure->isNumber($cdn_assets) || !$secure->isNumber($game_tooltip) || !$secure->isNumber($anti_adblock) || !$secure->isNumber($landscape_mode) || !$secure->isNumber($fullscreen) || !$secure->isNumber($_POST["default_avatar"])) {
        die("error");
    }

    $save = $sys->saveSystem("site_name", $site_name);
    $save = $sys->saveSystem("site_url", $site_url);
    $save = $sys->saveSystem("tags", $tags);
    $save = $sys->saveSystem("description", $description);
    $save = $sys->saveSystem("analytics", $analytics);    
    $save = $sys->saveSystem("smart_cache", $smart_cache);
    $save = $sys->saveSystem("cdn_assets", $cdn_assets);
    $save = $sys->saveSystem("submissions", $submissions);       
    $save = $sys->saveSystem("template", $template);    
    $save = $sys->saveSystem("template_color", $template_color);
    $save = $sys->saveSystem("game_tooltip", $game_tooltip);	
    $save = $sys->saveSystem("anti_adblock", $anti_adblock);    
    $save = $sys->saveSystem("landscape_mode", $landscape_mode);
    $save = $sys->saveSystem("fullscreen", $fullscreen);
    $save = $sys->saveSystem("featured", $featured);
    $save = $sys->saveSystem("footer_links", $footer_links);    
    $save = $sys->saveSystem("default_avatar", $default_avatar);
    $save = $sys->saveSystem("default_lang", $default_lang);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["challenge_daily"], $_POST["challenge_weekly"], $_POST["challenge_monthly"], $_POST["challenge_gp"], $_POST["challenge_gp_int"]) && $user["position"] == 1 && $_GET["do"] == "challenge") {
    $challenge_daily = $secure->purify($_POST["challenge_daily"]);
    $challenge_weekly = $secure->purify($_POST["challenge_weekly"]);
    $challenge_monthly = $secure->purify($_POST["challenge_monthly"]);
    $challenge_gp = $secure->purify($_POST["challenge_gp"]);
    $challenge_gp_int = $secure->purify($_POST["challenge_gp_int"]);    
    
    if (!$secure->isNumber($challenge_daily) || !$secure->isNumber($challenge_weekly) || !$secure->isNumber($challenge_monthly) || !$secure->isNumber($challenge_gp) || !$secure->isNumber($challenge_gp_int)) {
        die("error");
    }

    $save = $sys->saveSystem("challenge_daily", $challenge_daily);
    $save = $sys->saveSystem("challenge_weekly", $challenge_weekly);
    $save = $sys->saveSystem("challenge_monthly", $challenge_monthly);
    $save = $sys->saveSystem("challenge_gp", $challenge_gp);
    $save = $sys->saveSystem("challenge_gp_int", $challenge_gp_int);    
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_FILES["logo"]) && $user["position"] == 1 && $_GET["do"] == "logo") {
	if(empty($_FILES["logo"])){
		die("lempty");
	}
	
	$ldirectory = "../../uploads/";
	$lname = strtolower(rand(10000, 1000000) . "_" . basename($_FILES["logo"]["name"]));
	$lfile = $ldirectory . $lname;
	$lextension = strtolower(pathinfo($lfile, PATHINFO_EXTENSION));
	if (!in_array($lextension, array("png", "jpg", "jpeg", "gif"))) {
		die("lformat");    					
	} else {
		@unlink($ldirectory . $get->system("logo"));
		if (move_uploaded_file($_FILES["logo"]["tmp_name"], $ldirectory.sha1($lname).".".$lextension)) {
			$logo = sha1($lname).".".$lextension;    		
		} else {
			die("lerror");    							
		}		
	}
	
	$save = $sys->saveSystem("logo", $logo);    	
	if($save){
		die("success");
	} else {
		die("error");
	}  
} else if (isset($_SESSION["logged"], $_POST["sitemap"]) && $user["position"] == 1 && $_GET["do"] == "sitemap") {
	$sitemap = $secure->purify($_POST["sitemap"]);
	if(!$secure->isNumber($sitemap)){
		die("error");
	}
	$save = $sys->saveSystem("sitemap", $sitemap); 	
	if($save){
		die("success");
	} else {
		die("error");
	}
} else if (isset($_SESSION["logged"], $_POST["pcode"], $_POST["import_type"], $_POST["import_games"], $_POST["import_limit"], $_POST["auto_publish"]) && $user["position"] == 1 && $_GET["do"] == "import") {
    $pcode = $secure->purify($_POST["pcode"]); 	
    $import_type = $secure->purify($_POST["import_type"]);    
    $import_games = $secure->purify($_POST["import_games"]);
    $import_limit = $secure->purify($_POST["import_limit"]);    
    $auto_publish = $secure->purify($_POST["auto_publish"]);
    
    if(!$secure->isNumber($import_limit)){
    	 die("error");
    }
            
    $save = $sys->saveSystem("pcode", $pcode);               
    $save = $sys->saveSystem("import_type", $import_type);       
    $save = $sys->saveSystem("import_games", $import_games);    
    $save = $sys->saveSystem("import_limit", $import_limit);       
    $save = $sys->saveSystem("auto_publish", $auto_publish);    
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_POST["default_comments"], $_POST["fb_comments"], $_POST["disqus_comments"], $_POST["disqus"]) && $user["position"] == 1 && $_GET["do"] == "comments") {
    $default_comments = $secure->purify($_POST["default_comments"]);    
    $fb_comments = $secure->purify($_POST["fb_comments"]);
    $disqus_comments = $secure->purify($_POST["disqus_comments"]);    
	$disqus = $secure->purify($_POST["disqus"]);
    
    if(!$secure->isNumber($default_comments) || !$secure->isNumber($fb_comments) || !$secure->isNumber($disqus_comments)){
    	 die("error");
    }
                         
    $save = $sys->saveSystem("default_comments", $default_comments);       
    $save = $sys->saveSystem("fb_comments", $fb_comments);    
    $save = $sys->saveSystem("disqus_comments", $disqus_comments);     
	$save = $sys->saveSystem("disqus", $disqus);	
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_POST["advance_search"], $_POST["search_length"], $_POST["search_max"], $_POST["detectlang_api"]) && $user["position"] == 1 && $_GET["do"] == "search") {
    $advance_search = $secure->purify($_POST["advance_search"]);    
    $search_length = $secure->purify($_POST["search_length"]);
    $search_max = $secure->purify($_POST["search_max"]);    
	$detectlang_api = $secure->purify($_POST["detectlang_api"]);
    
    if(!$secure->isNumber($advance_search)){
    	 die("error");
    }
                         
    $save = $sys->saveSystem("advance_search", $advance_search);       
    $save = $sys->saveSystem("search_length", $search_length);    
    $save = $sys->saveSystem("search_max", $search_max);     
	$save = $sys->saveSystem("detectlang_api", $detectlang_api);	
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["cron_password"], $_POST["trash_clear"], $_POST["cache_clear"], $_POST["shoutbox_clear"]) && $user["position"] == 1 && $_GET["do"] == "arcanox") {
    $cron_password = $secure->purify($_POST["cron_password"]);
    $trash_clear = $secure->purify($_POST["trash_clear"]);
    $cache_clear = $secure->purify($_POST["cache_clear"]);
    $shoutbox_clear = $secure->purify($_POST["shoutbox_clear"]);
            
    $save = $sys->saveSystem("cron_password", $cron_password);
    $save = $sys->saveSystem("trash_clear", $trash_clear);
    $save = $sys->saveSystem("cache_clear", $cache_clear);
    $save = $sys->saveSystem("shoutbox_clear", $shoutbox_clear);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["fb_id"], $_POST["fb_secret"], $_POST["gp_id"], $_POST["gp_secret"], $_POST["tw_id"], $_POST["tw_secret"]) && $user["position"] == 1 && $_GET["do"] == "api") {
    $fb_id = $secure->purify($_POST["fb_id"]);
    $fb_secret = $secure->purify($_POST["fb_secret"]);
    $gp_id = $secure->purify($_POST["gp_id"]);
    $gp_secret = $secure->purify($_POST["gp_secret"]);
    $tw_id = $secure->purify($_POST["tw_id"]);
    $tw_secret = $secure->purify($_POST["tw_secret"]);
    $save = $sys->saveSystem("fb_id", $fb_id);
    $save = $sys->saveSystem("fb_secret", $fb_secret);
    $save = $sys->saveSystem("gp_id", $gp_id);
    $save = $sys->saveSystem("gp_secret", $gp_secret);
    $save = $sys->saveSystem("tw_id", $tw_id);
    $save = $sys->saveSystem("tw_secret", $tw_secret);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["avatar_size"], $_POST["cover_size"], $_POST["thumb_size"], $_POST["game_size"], $_POST["avatar_allowed"], $_POST["cover_allowed"], $_POST["thumb_allowed"]) && $user["position"] == 1 && $_GET["do"] == "uploads") {
    $avatar_size = $secure->purify($_POST["avatar_size"]);
    $cover_size = $secure->purify($_POST["cover_size"]);
    $thumb_size = $secure->purify($_POST["thumb_size"]);
    $game_size = $secure->purify($_POST["game_size"]);
    $avatar_allowed = $secure->purify($_POST["avatar_allowed"]);
    $cover_allowed = $secure->purify($_POST["cover_allowed"]);
    $thumb_allowed = $secure->purify($_POST["thumb_allowed"]);
    $save = $sys->saveSystem("avatar_size", $avatar_size);
    $save = $sys->saveSystem("cover_size", $cover_size);
    $save = $sys->saveSystem("thumb_size", $thumb_size);
    $save = $sys->saveSystem("game_size", $game_size);
    $save = $sys->saveSystem("avatar_allowed", $avatar_allowed);
    $save = $sys->saveSystem("cover_allowed", $cover_allowed);
    $save = $sys->saveSystem("thumb_allowed", $thumb_allowed);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["online_limit"], $_POST["leaderboard_limit"], $_POST["cat_page_limit"], $_POST["search_limit"], $_POST["latest_limit"], $_POST["featured_limit"], $_POST["popular_limit"], $_POST["random_limit"], $_POST["topusers_limit"], $_POST["favorites_limit"], $_POST["related_limit"], $_POST["recent_search_limit"], $_POST["recent_played_limit"], $_POST["recent_comments_limit"], $_POST["topexp_limit"], $_POST["recent_users_limit"], $_POST["recent_players_limit"], $_POST["challenge_limit"]) && $user["position"] == 1 && $_GET["do"] == "limits") {
    $online_limit = $secure->purify($_POST["online_limit"]);
    $leaderboard_limit = $secure->purify($_POST["leaderboard_limit"]);
    $cat_page_limit = $secure->purify($_POST["cat_page_limit"]);
    $search_limit = $secure->purify($_POST["search_limit"]);
    $latest_limit = $secure->purify($_POST["latest_limit"]);
    $featured_limit = $secure->purify($_POST["featured_limit"]);
    $popular_limit = $secure->purify($_POST["popular_limit"]);
    $random_limit = $secure->purify($_POST["random_limit"]);
    $topusers_limit = $secure->purify($_POST["topusers_limit"]);
    $favorites_limit = $secure->purify($_POST["favorites_limit"]);
    $related_limit = $secure->purify($_POST["related_limit"]);
    $recent_search_limit = $secure->purify($_POST["recent_search_limit"]);
    $recent_played_limit = $secure->purify($_POST["recent_played_limit"]);    
    $recent_comments_limit = $secure->purify($_POST["recent_comments_limit"]);
    $topexp_limit = $secure->purify($_POST["topexp_limit"]);    
    $recent_users_limit = $secure->purify($_POST["recent_users_limit"]);
    $recent_players_limit = $secure->purify($_POST["recent_players_limit"]);
    $challenge_limit = $secure->purify($_POST["challenge_limit"]);
    
    $save = $sys->saveSystem("online_limit", $online_limit);
    $save = $sys->saveSystem("leaderboard_limit", $leaderboard_limit);
    $save = $sys->saveSystem("cat_page_limit", $cat_page_limit);
    $save = $sys->saveSystem("search_limit", $search_limit);
    $save = $sys->saveSystem("latest_limit", $latest_limit);
    $save = $sys->saveSystem("featured_limit", $featured_limit);
    $save = $sys->saveSystem("popular_limit", $popular_limit);
    $save = $sys->saveSystem("random_limit", $random_limit);
    $save = $sys->saveSystem("topusers_limit", $topusers_limit);
    $save = $sys->saveSystem("favorites_limit", $favorites_limit);
    $save = $sys->saveSystem("related_limit", $related_limit);
    $save = $sys->saveSystem("recent_search_limit", $recent_search_limit);
    $save = $sys->saveSystem("recent_played_limit", $recent_played_limit);    
    $save = $sys->saveSystem("recent_comments_limit", $recent_comments_limit);
    $save = $sys->saveSystem("topexp_limit", $topexp_limit);    
    $save = $sys->saveSystem("recent_users_limit", $recent_users_limit);
    $save = $sys->saveSystem("recent_players_limit", $recent_players_limit);
    $save = $sys->saveSystem("challenge_limit", $challenge_limit);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["gaming_exp"], $_POST["timer_exp"], $_POST["comment_exp"], $_POST["addgame_exp"], $_POST["exp_game"], $_POST["exp_time"], $_POST["exp_comment"], $_POST["exp_addgame"], $_POST["exp_time_duration"]) && $user["position"] == 1 && $_GET["do"] == "exp") {
    $gaming_exp = $secure->purify($_POST["gaming_exp"]);
    $timer_exp = $secure->purify($_POST["timer_exp"]);
    $comment_exp = $secure->purify($_POST["comment_exp"]);
    $addgame_exp = $secure->purify($_POST["addgame_exp"]);
    $ref_exp = $secure->purify($_POST["ref_exp"]);
    $exp_game = $secure->purify($_POST["exp_game"]);
    $exp_time = $secure->purify($_POST["exp_time"]);
    $exp_comment = $secure->purify($_POST["exp_comment"]);
    $exp_addgame = $secure->purify($_POST["exp_addgame"]);
    $exp_ref = $secure->purify($_POST["exp_ref"]);
    $exp_time_duration = $secure->purify($_POST["exp_time_duration"]);
    if (!$secure->isNumber($exp_game) && !$secure->isNumber($exp_time) && !$secure->isNumber($exp_comment) && !$secure->isNumber($exp_addgame) && !$secure->isNumber($exp_ref) && !$secure->isNumber($exp_time_duration)) {
        die("error");
    }
    $save = $sys->saveSystem("gaming_exp", $gaming_exp);
    $save = $sys->saveSystem("timer_exp", $timer_exp);
    $save = $sys->saveSystem("comment_exp", $comment_exp);
    $save = $sys->saveSystem("addgame_exp", $addgame_exp);
    $save = $sys->saveSystem("ref_exp", $ref_exp);
    $save = $sys->saveSystem("exp_game", $exp_game);
    $save = $sys->saveSystem("exp_time", $exp_time);
    $save = $sys->saveSystem("exp_comment", $exp_comment);
    $save = $sys->saveSystem("exp_addgame", $exp_addgame);
    $save = $sys->saveSystem("exp_ref", $exp_ref);
    $save = $sys->saveSystem("exp_time_duration", $exp_time_duration);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["game_ad"], $_POST["game_ad_duration"]) && $user["position"] == 1 && $_GET["do"] == "gameads") {
    $game_ad = $secure->purify($_POST["game_ad"]);
    $game_ad_duration = $secure->purify($_POST["game_ad_duration"]);
    if (!$secure->isNumber($game_ad) || !$secure->isNumber($game_ad_duration)) {
        die("error");
    }
    $save = $sys->saveSystem("game_ad", $game_ad);
    $save = $sys->saveSystem("game_ad_duration", $game_ad_duration);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["enable_chat"], $_POST["guest_chat"], $_POST["chat_filter"]) && $user["position"] == 1 && $_GET["do"] == "chat" && $secure->isNumber($_POST["enable_chat"]) && $secure->isNumber($_POST["guest_chat"])) {
    $enable_chat = $secure->purify($_POST["enable_chat"]);
    $guest_chat = $secure->purify($_POST["guest_chat"]);
    $chat_filter = $secure->purify($_POST["chat_filter"]);
    $save = $sys->saveSystem("enable_chat", $enable_chat);
    $save = $sys->saveSystem("guest_chat", $guest_chat);
    $save = $sys->saveSystem("chat_filter", $chat_filter);
    if ($save) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["user"]) && $user["position"] == 1 && $_GET["do"] == "searchusers") {
    $user = $secure->purify($_POST["user"]);
    if (empty($user)) {
        die("error");
    }
    $find_user = $db->query("SELECT id, username FROM users WHERE username LIKE '%" . $user . "%' LIMIT 10");
    if ($find_user->num_rows > 0) {
        echo '<br /><h4><i class="fa fa-search"></i> '.$lang["parts_usersfound_panel"].'</h4><br />';
        while ($user = $find_user->fetch_assoc()) {
            echo '<ul class="list-group animated bounceIn">
   	 	 	 <li class="list-group-item user-' . $user["id"] . '">
   	 	 	 ' . ucfirst($user["username"]) . '
   	 	 	 &nbsp;
   	 	 	 <a href="' . $get->system("site_url") . '/panel/edit/user/' . $user["id"] . '" class="btn btn-success btn-xs">'.$lang["edit_btn"].'</a>
   	 	 	 <span class="btn btn-danger btn-xs" onclick="deleteUser(' . $user["id"] . ')">'.$lang["delete_btn"].'</span>
   	 	 	 </li>
   	 	 	 </ul>';
        }
    } else {
        die("nothingfound");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["game"]) && $user["position"] == 1 && $_GET["do"] == "searchgames") {
    $game = $secure->purify($_POST["game"]);
    if (empty($game)) {
        die("error");
    }
    $find_game = $db->query("SELECT id, name FROM games WHERE name LIKE '%" . $game . "%' LIMIT 10");
    if ($find_game->num_rows > 0) {
        echo '<br /><h4><i class="fa fa-search"></i> Games Found</h4><br />';
        while ($game = $find_game->fetch_assoc()) {
            echo '<ul class="list-group animated bounceIn">
   	 	 	 <li class="list-group-item game-' . $game["id"] . '">
   	 	 	 ' . ucfirst($game["name"]) . '
   	 	 	 &nbsp;
   	 	 	 <a href="' . $get->system("site_url") . '/game/edit/' . $game["id"] . '" class="btn btn-success btn-xs">'.$lang["edit_btn"].'</a>
   	 	 	 <span class="btn btn-danger btn-xs" onclick="deleteGame(' . $game["id"] . ')">'.$lang["delete_btn"].'</span>
   	 	 	 </li>
   	 	 	 </ul>';
        }
    } else {
        die("nothingfound");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $user["position"] == 1 && $_GET["do"] == "deleteuser" && $secure->isNumber($_GET["id"])) {
    $id = $secure->purify($_GET["id"]);
    if ($id == 1) {
        die("admin");
    }
    $delete = $db->query("DELETE FROM users WHERE id = $id LIMIT 1");
    $delete = $db->query("DELETE FROM games WHERE uid = $id");    
    $delete = $db->query("DELETE FROM favorites WHERE uid = $id");
    $delete = $db->query("DELETE FROM shoutbox WHERE uid = $id");        
    $delete = $db->query("DELETE FROM comments WHERE uid = $id");    
    $delete = $db->query("DELETE FROM lastplayers WHERE id = $id");    
    $delete = $db->query("DELETE FROM reports WHERE uid = $id");    
    if ($delete) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $user["position"] == 1 && $_GET["do"] == "deletegame" && $secure->isNumber($_GET["id"])) {
    $gid = $secure->purify($_GET["id"]);
    $check_game = $db->query("SELECT unique_id, thumb, source FROM games WHERE id = '$gid' LIMIT 1");
    if ($check_game->num_rows > 0) {
        $game_data = $check_game->fetch_assoc();
        @unlink("../../uploads/thumbs/" . $game_data["thumb"]);
        @unlink("../../uploads/games/" . $game_data["source"]);
		$dump = $db->query("INSERT INTO dump (unique_id) VALUES ('".$game_data["unique_id"]."');"); 
        $delete = $db->query("DELETE FROM games WHERE id = $gid LIMIT 1");
        $delete = $db->query("DELETE FROM lastplayers WHERE gid = $gid");
        $delete = $db->query("DELETE FROM favorites WHERE id = $gid");
        $delete = $db->query("DELETE FROM reports WHERE gid = $gid");
        $delete = $db->query("DELETE FROM comments WHERE gid = $gid");
        $delete = $db->query("DELETE FROM lastplayed WHERE gid = $gid"); 		
        if ($delete && $dump) {
            die('success');
        } else {
            die("error");
        }
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["uid"], $_POST["username"], $_POST["email"], $_POST["position"], $_POST["banned"], $_POST["fullname"], $_POST["password"], $_POST["exp"], $_POST["website"], $_POST["quote"], $_POST["about"], $_POST["avatar"], $_POST["cover"]) && $user["position"] == 1 && $_GET["do"] == "edituser" && $secure->isNumber($_POST["uid"]) && $secure->isNumber($_POST["position"]) && $secure->isNumber($_POST["exp"])) {
    $id = $secure->purify($_POST["uid"]);
    $username = $secure->purify($_POST["username"]);
    $email = $secure->washEmail($_POST["email"]);
    $position = $secure->purify($_POST["position"]);
    $banned = $secure->purify($_POST["banned"]);
    $fullname = $secure->purify($_POST["fullname"]);
    if (!empty($_POST["password"])) {
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    }
    $exp = $secure->purify($_POST["exp"]);
    $website = $secure->washUrl($_POST["website"]);
    $quote = $secure->purify($_POST["quote"]);
    $about = $secure->purify($_POST["about"]);
    $avatar = $secure->purify($_POST["avatar"]);
    $cover = $secure->purify($_POST["cover"]);
    if (!$secure->checkUsername(str_replace(" ", "#", $username))) {
        die("invalid");
    }
    if (empty($username) || empty($email) || empty($position) || empty($fullname)) {
        die("error");
    }
    $get_user = $db->query("SELECT id, position, username, avatar, cover, email, banned FROM users WHERE id = $id LIMIT 1");
    if ($get_user->num_rows > 0) {
        $udata = $get_user->fetch_assoc();
        if ($username !== $udata["username"]) {
            $check_username = $db->query("SELECT username FROM users WHERE username = '$username' LIMIT 1");
            if ($check_username->num_rows > 0) {
                die("username");
            } else {
                $update = $db->query("UPDATE users SET username = '$username' WHERE id = $id LIMIT 1");
            }
        }
        if ($email !== $udata["email"]) {
            $check_email = $db->query("SELECT email FROM users WHERE email = '$email' LIMIT 1");
            if ($check_email->num_rows > 0) {
                die("email");
            } else {
                $update = $db->query("UPDATE users SET email = '$email' WHERE id = $id LIMIT 1");
            }
        }
        if ($id == 1 && $position !== $udata["position"]) {
            die("admin");
        }
        if ($id > 1 && $position !== $udata["position"]) {
            $update = $db->query("UPDATE users SET position = $position WHERE id = $id LIMIT 1");
        }
        if ($id == 1 && $banned !== $udata["banned"]) {
            die("adminbanned");
        }
        if ($id > 1 && $banned !== $udata["banned"]) {
            $update = $db->query("UPDATE users SET banned = $banned WHERE id = $id LIMIT 1");
        }
        if ($avatar == 1) {
            @unlink("../../uploads/avatars/" . $udata["avatar"]);
            $update = $db->query("UPDATE users SET avatar = '' WHERE id = $id LIMIT 1");
        }
        if ($cover == 1) {
            @unlink("../../uploads/covers/" . $udata["cover"]);
            $update = $db->query("UPDATE users SET cover = '' WHERE id = $id LIMIT 1");
        }
    } else {
        die("error");
    }
    $update = $db->query("UPDATE users SET fullname = '$fullname' WHERE id = $id LIMIT 1");
    if (!empty($_POST["password"])) {
        $update = $db->query("UPDATE users SET password = '$password' WHERE id = $id LIMIT 1");
    }
    $update = $db->query("UPDATE users SET exp = '$exp' WHERE id = $id LIMIT 1");
    $update = $db->query("UPDATE users SET website = '$website' WHERE id = $id LIMIT 1");
    $update = $db->query("UPDATE users SET quote = '$quote' WHERE id = $id LIMIT 1");
    $update = $db->query("UPDATE users SET about = '$about' WHERE id = $id LIMIT 1");
    if ($update) {
    	   if($get->system("smart_cache") == 1){
        	$sys->clearCache("user", "../../cache/users/", $secure->hashed($id));    	   	
    	   }
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["widget_banner_top"], $_POST["widget_banner_bottom"], $_POST["widget_banner_play"], $_POST["game_banner_top"], $_POST["game_banner_bottom"], $_POST["widget_sidebar_global"], $_POST["widget_sidebar_play"]) && $user["position"] == 1 && $_GET["do"] == "widgets") {
    $widget_banner_top = $secure->washWidget($_POST["widget_banner_top"]);
    $widget_banner_bottom = $secure->washWidget($_POST["widget_banner_bottom"]);
    $widget_banner_play = $secure->washWidget($_POST["widget_banner_play"]);
    $game_banner_top = $secure->washWidget($_POST["game_banner_top"]);
    $game_banner_bottom = $secure->washWidget($_POST["game_banner_bottom"]);
    $widget_sidebar_global = $secure->washWidget($_POST["widget_sidebar_global"]);
    $widget_sidebar_play = $secure->washWidget($_POST["widget_sidebar_play"]);
    $update = $sys->saveSystem("widget_banner_top", $widget_banner_top);
    $update = $sys->saveSystem("widget_banner_bottom", $widget_banner_bottom);
    $update = $sys->saveSystem("widget_banner_play", $widget_banner_play);
    $update = $sys->saveSystem("game_banner_top", $game_banner_top);
    $update = $sys->saveSystem("game_banner_bottom", $game_banner_bottom);
    $update = $sys->saveSystem("widget_sidebar_global", $widget_sidebar_global);
    $update = $sys->saveSystem("widget_sidebar_play", $widget_sidebar_play);
    if ($update) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["lang_name"], $_POST["lang_code"], $_POST["country_code"], $_POST["rtl"]) && $user["position"] == 1 && $_GET["do"] == "newlang" && $secure->isNumber($_POST["rtl"])) {
    $lang_name = $secure->purify($_POST["lang_name"]);
    $lang_code = $secure->purify($_POST["lang_code"]);
    $country_code = $secure->purify($_POST["country_code"]);
    $rtl = $secure->purify($_POST["rtl"]);
    if (empty($lang_name) || empty($lang_code) || empty($country_code)) {
        die("empty");
    }
    $new = $db->query("INSERT INTO languages (name, code, country_code, rtl) VALUES ('$lang_name', '$lang_code', '$country_code', $rtl);");
    if ($new) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["id"], $_POST["lang_name"], $_POST["lang_code"], $_POST["country_code"], $_POST["rtl"]) && $user["position"] == 1 && $_GET["do"] == "editlang" && $secure->isNumber($_POST["id"]) && $secure->isNumber($_POST["rtl"])) {
    $id = $secure->purify($_POST["id"]);
    $lang_name = $secure->purify($_POST["lang_name"]);
    $lang_code = $secure->purify($_POST["lang_code"]);
    $country_code = $secure->purify($_POST["country_code"]);
    $rtl = $secure->purify($_POST["rtl"]);
    if (empty($lang_name) || empty($lang_code) || empty($country_code)) {
        die("empty");
    }
    $update = $db->query("UPDATE languages SET name = '$lang_name', code = '$lang_code', country_code = '$country_code', rtl = $rtl WHERE id = $id LIMIT 1");
    if ($update) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $user["position"] == 1 && $_GET["do"] == "deletelang" && $secure->isNumber($_GET["id"])) {
    $id = $secure->purify($_GET["id"]);
    $delete = $db->query("DELETE FROM languages WHERE id = $id LIMIT 1");
    if ($delete) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["cat_name"], $_POST["seo"], $_POST["cat_desc"]) && $user["position"] == 1 && $_GET["do"] == "newcat") {
    $cat_name = $secure->purify($_POST["cat_name"]);
    $seo = $secure->purify($_POST["seo"]);
    $cat_desc = $secure->purify($_POST["cat_desc"]);
    if (empty($cat_name) || empty($cat_desc)) {
        die("empty");
    }
    $find_cat = $db->query("SELECT name FROM categories WHERE name = '$cat_name' LIMIT 1");
    if ($find_cat->num_rows > 0) {
        die("exist");
    }
    if(!empty($seo)){
    	$find_seo = $db->query("SELECT seo FROM categories WHERE seo = '$seo' LIMIT 1");
    	if ($find_seo->num_rows > 0) {
    		die("seoexist");    		
    	}   
    }
    $new = $db->query("INSERT INTO categories (name, seo, description) VALUES ('$cat_name', '$seo', '$cat_desc');");
    if ($new) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["id"], $_POST["cat_name"], $_POST["seo"], $_POST["cat_desc"]) && $user["position"] == 1 && $_GET["do"] == "editcat" && $secure->isNumber($_POST["id"])) {
    $id = $secure->purify($_POST["id"]);
    $cat_name = $secure->purify($_POST["cat_name"]);
    $seo = $secure->purify($_POST["seo"]);    
    $cat_desc = $secure->purify($_POST["cat_desc"]);
    if (empty($cat_name) || empty($cat_desc)) {
        die("empty");
    }
    $find_real = $db->query("SELECT name, seo FROM categories WHERE id = $id LIMIT 1");
    if ($find_real->num_rows > 0) {
        $real_data = $find_real->fetch_assoc();
        if ($cat_name == $real_data["name"]) {
            $update = $db->query("UPDATE categories SET description = '$cat_desc' WHERE id = $id LIMIT 1");
        } else {
            $find_cat = $db->query("SELECT name FROM categories WHERE name = '$cat_name' LIMIT 1");
            if ($find_cat->num_rows > 0) {
                die("exist");
            } else {
                $update = $db->query("UPDATE categories SET name = '$cat_name', description = '$cat_desc' WHERE id = $id LIMIT 1");
                if ($update) {
                    die("success");
                } else {
                    die("error");
                }
            }
        }
        if(!empty($seo)){
        	$find_seo = $db->query("SELECT seo FROM categories WHERE id = $id LIMIT 1");
        	if($find_seo->num_rows > 0){
        		$cat_seo = $find_seo->fetch_assoc();
        		if($seo !== $cat_seo["seo"]){
        			$find_r_seo = $db->query("SELECT seo FROM categories WHERE seo = '$seo' LIMIT 1");
        			if($find_r_seo->num_rows < 1){
        				$update = $db->query("UPDATE categories SET seo = '$seo' WHERE id = $id LIMIT 1");        			        				        					
        			} else {
        				die("seoexist");
        			}	        		
        		}
        	} 
        }    	
        if($update){
        	die("success");
        } else {
        	die("error");
        }
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $user["position"] == 1 && $_GET["do"] == "deletecat" && $secure->isNumber($_GET["id"])) {
    $id = $secure->purify($_GET["id"]);
    $delete = $db->query("DELETE FROM categories WHERE id = $id LIMIT 1");
    $delete = $db->query("DELETE FROM games WHERE category = $id");
    if ($delete) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["category"], $_POST["id"]) && $user["position"] == 1 && $_GET["do"] == "movegames" && $secure->isNumber($_POST["category"]) && $secure->isNumber($_POST["id"])) {
    $category = $secure->purify($_POST["category"]);
    $cat_id = $secure->purify($_POST["id"]);
    
    $move = $db->query("UPDATE games SET category = $category WHERE category = $cat_id");
    $delete = $db->query("DELETE FROM categories WHERE id = $cat_id LIMIT 1");
    
    if($move && $delete){
    	 die("success");
    } else {
    	 die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["page_name"], $_POST["page_content"]) && $user["position"] == 1 && $_GET["do"] == "newpage") {
    $name = $secure->purify($_POST["page_name"]);
    $content = $db->real_escape_string(htmlspecialchars($secure->strip(urldecode($_POST["page_content"]))));
    if (empty($name) || empty($content)) {
        die("empty");
    }
    $new = $db->query("INSERT INTO pages (name, content) VALUES ('$name', '$content');");
    if ($new) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_POST["id"], $_POST["page_name"], $_POST["page_content"]) && $user["position"] == 1 && $_GET["do"] == "editpage" && $secure->isNumber($_POST["id"])) {
    $id = $secure->purify($_POST["id"]);
    $name = $secure->purify($_POST["page_name"]);
    $content = $db->real_escape_string(htmlspecialchars($secure->strip(urldecode($_POST["page_content"]))));
    if (empty($name) || empty($content)) {
        die("empty");
    }
    $update = $db->query("UPDATE pages SET name = '$name', content = '$content' WHERE id = $id LIMIT 1");
    if ($update) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $user["position"] == 1 && $_GET["do"] == "deletepage" && $secure->isNumber($_GET["id"])) {
    $id = $secure->purify($_GET["id"]);
    $delete = $db->query("DELETE FROM pages WHERE id = $id LIMIT 1");
    if ($delete) {
        die("success");
    } else {
        die("error");
    }
} else if (isset($_SESSION["logged"], $_GET["do"], $_GET["id"]) && $user["position"] == 1 && $_GET["do"] == "deletereport" && $secure->isNumber($_GET["id"])) {
    $id = $secure->purify($_GET["id"]);
    $delete = $db->query("DELETE FROM reports WHERE id = $id LIMIT 1");
    if ($delete) {
        die("success");
    } else {
        die("error");
    }
} else {
    die("error");
}
/* End */
?>