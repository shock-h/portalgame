<?php
define("DB_HOST", "dbhost");
define("DB_NAME", "dbname");
define("DB_USER", "dbuser");
define("DB_PASS", "dbpass");
?>