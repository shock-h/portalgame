<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com>
 */
 
 /**
  * Start Session
  */
  
  session_start();
 
 /**
  * Process Requests
  */
  
  if(isset($_GET["do"]) && $_GET["do"] == "check"){
  	if(function_exists('mysqli_connect')){
  		$r_1 = true;
  	} else {
  		$r_1 = false; 		
  	}
  	
  	if(is_dir("../system/") && is_writable("../system/")){
  		$r_2 = true; 	  		
  	} else {
  		$r_2 = false;
  	}
  	
  	if(is_dir("../uploads/") && is_writable("../uploads/")){
  		$r_3 = true; 	  		
  	} else {
  		$r_3 = false;
  	}  	  	
  	
  	if(is_dir("../cache/") && is_writable("../cache/")){
  		$r_4 = true; 	  		
  	} else {
  		$r_4 = false;
  	}  	
  	
  	if(is_writable("../system/config.php")){
  		$r_5 = true; 	  		
  	} else {
  		$r_5 = false;
  	}  	  	
  	
  	if($r_1 && $r_2 && $r_3 && $r_4 && $r_5){
  		echo '<div class="alert alert-success">
  		<p class="lead">
  		<i class="fa fa-server"></i> All requirements met, please continue!
  		</p>
  		</div>';
  	} else {
  		echo '<div class="alert alert-danger">
  		<p class="lead">
  		<i class="fa fa-exclamation-circle"></i> Please fix the following errors!
  		</p>
  		</div>';  		
  	} 	
  	echo '<ul class="list-group">';
  	if($r_1){
  		echo '<li class="list-group-item" style="color: green"><i class="fa fa-check"></i> MySQLi extension supported!</li>';
  	} else {
  		echo '<li class="list-group-item" style="color: red"><i class="fa fa-close"></i> MySQLi extension not supported!</li>';
  	}
  	if($r_2){
  		echo '<li class="list-group-item" style="color: green"><i class="fa fa-check"></i> ../system/ is writable!</li>';
  	} else {
  		echo '<li class="list-group-item" style="color: red"><i class="fa fa-close"></i> ../system/ is not writable, please chmod to 755!</li>';
  	}
  	if($r_3){
  		echo '<li class="list-group-item" style="color: green"><i class="fa fa-check"></i> ../uploads/ is writable!</li>';
  	} else {
  		echo '<li class="list-group-item" style="color: red"><i class="fa fa-close"></i> ../uploads/ is not writable, please chmod to 777!</li>';
  	}
  	if($r_4){
  		echo '<li class="list-group-item" style="color: green"><i class="fa fa-check"></i> ../cache/ is writable!</li>';
  	} else {
  		echo '<li class="list-group-item" style="color: red"><i class="fa fa-close"></i> ../cache/ is not writable, please chmod to 777!</li>';
  	}  	  	  	
  	if($r_5){
  		echo '<li class="list-group-item" style="color: green"><i class="fa fa-check"></i> ../system/config.php is writable!</li>';
  	} else {
  		echo '<li class="list-group-item" style="color: red"><i class="fa fa-close"></i> ../system/config.php is not writable, please chmod to 777!</li>';
  	}  	  	  	  	
  	echo '</ul>';
 } else if(isset($_GET["do"]) && $_GET["do"] == "database"){
	if(!isset($_POST["host"], $_POST["name"], $_POST["username"], $_POST["password"])){
		die("error");
	} else {
		$mysqli = @new mysqli($_POST["host"], $_POST["username"], $_POST["password"], $_POST["name"]); 
		
		if(mysqli_connect_errno()){
			die("invalid");
		} else {
			$config_data = '<?php
define("DB_HOST", "'.$_POST["host"].'");
define("DB_NAME", "'.$_POST["name"].'");
define("DB_USER", "'.$_POST["username"].'");
define("DB_PASS", "'.$_POST["password"].'");
?>';
			
			$config_file = fopen("../system/config.php", "w+");
			fwrite($config_file, $config_data);
			fclose($config_file); 			
			
			require '../system/database.php';					
			
			/** 
			 * Install Tables
			 */
			 
			$settings = "CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `value` varchar(5000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$users = "CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(1500) NOT NULL,
  `email` varchar(150) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `cover` varchar(250) NOT NULL,
  `exp` int(11) NOT NULL,
  `dgp` int(11) NOT NULL,  
  `wgp` int(11) NOT NULL,  
  `mgp` int(11) NOT NULL,  
  `fullname` varchar(200) NOT NULL,
  `website` varchar(250) NOT NULL,
  `quote` varchar(300) NOT NULL,
  `fb_link` varchar(300) NOT NULL,
  `gp_link` varchar(300) NOT NULL,
  `tw_link` varchar(300) NOT NULL,      
  `about` varchar(500) NOT NULL,
  `banned` int(11) NOT NULL,
  `robohash` int(11) NOT NULL,  
  `language` varchar(100) NOT NULL,
  `ref` int(11) NOT NULL,
  `registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activity` int(11) NOT NULL,  
  `status` int(11) NOT NULL,  
  `oauth_name` varchar(250) NOT NULL,
  `oauth_id` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$favorites = "CREATE TABLE IF NOT EXISTS `favorites` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;";
			$games = "CREATE TABLE IF NOT EXISTS `games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `source` varchar(250) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `thumb` varchar(250) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `mobile` int(11) NOT NULL,
  `help` varchar(500) NOT NULL,
  `plays` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_id` (`unique_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$lastplayers = "CREATE TABLE IF NOT EXISTS `lastplayers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$lastplayed = "CREATE TABLE IF NOT EXISTS `lastplayed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$comments = "CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;"; 		
			$categories = "CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(300) NOT NULL,  
  `seo` varchar(300) NOT NULL,  
  `name` varchar(300) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$languages = "CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `country_code` varchar(100) NOT NULL,
  `rtl` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$reports = "CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `problem` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$pages = "CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$search = "CREATE TABLE IF NOT EXISTS `search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `query` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$shoutbox = "CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `message` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			$dump_games = "CREATE TABLE IF NOT EXISTS `dump` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
			
			$install = $db->query($settings);
			$install = $db->query($games); 			
			$install = $db->query($lastplayers);		 		
			$install = $db->query($lastplayed);		 		 				
			$install = $db->query($categories);
			$install = $db->query($reports);
			$install = $db->query($pages);
			$install = $db->query($search);
			$install = $db->query($comments);
			$install = $db->query($favorites);
			$install = $db->query($languages);
			$install = $db->query($shoutbox);
			$install = $db->query($dump_games);
			$install = $db->query($users);			 			 			 			 			 			
						
			/**
			 * Table Dumps
			 */
			 
			$settings_dump = "INSERT INTO `settings` (`name`, `value`) VALUES
('site_name', ''),
('site_url', ''),
('logo', ''),
('protocol', ''),
('smart_cache', '0'),
('cdn_assets', '0'),
('sitemap', '1'),
('submissions', '1'),
('template', 'default'),
('template_color', 'default'),
('tags', 'arcade, games, cut the rope, free games, flash games, html5'),
('description', 'Play thousands of games for free!'),
('analytics', ''),
('game_tooltip', '1'),
('anti_adblock', '1'),
('landscape_mode', '0'),
('fullscreen', '1'),
('default_lang', 'en'),
('default_avatar', 3),
('featured', '1,2,3,4,5,6,7,8'),
('footer_links', '1,2,3,4'),
('fb_id', ''),
('fb_secret', ''),
('gp_id', ''),
('gp_secret', ''),
('tw_id', ''),
('tw_secret', ''),
('disqus', ''),
('default_comments', '1'),
('fb_comments', '1'),
('disqus_comments', '1'),
('online_limit', '20'),
('cat_page_limit', '12'),
('search_limit', '12'),
('featured_limit', '12'),
('popular_limit', '12'),
('random_limit', '12'),
('topusers_limit', '4'),
('favorites_limit', '12'),
('latest_limit', '8'),
('related_limit', '8'),
('search_length', '3'),
('leaderboard_limit', '12'),
('recent_played_limit', '5'),
('recent_comments_limit', '5'),
('topexp_limit', '5'),
('recent_users_limit', '5'),
('recent_players_limit', '5'),
('comments_limit', '10'),
('recent_search_limit', '40'),
('challenge_limit', '12'),
('comment_exp', '1'),
('addgame_exp', '1'),
('gaming_exp', '1'),
('timer_exp', '1'),
('ref_exp', '1'),
('exp_game', '100'),
('exp_time', '50'),
('exp_addgame', '200'),
('exp_comment', '50'),
('exp_ref', '30'),
('exp_time_duration', '2'),
('game_ad', '1'),
('game_ad_duration', '10'),
('enable_chat', '1'),
('guest_chat', '0'),
('chat_filter', 'shit, fuck, bitch, stupid'),
('widget_sidebar_global', ''),
('widget_banner_top', ''),
('widget_banner_bottom', ''),
('widget_sidebar_play', ''),
('game_banner_top', ''),
('game_banner_bottom', ''),
('widget_banner_play', ''),
('cron_password', 'arcanox'),
('trash_clear', '1'),
('cache_clear', '1'),
('shoutbox_clear', '1'),
('challenge_daily', '1'),
('challenge_weekly', '1'),
('challenge_monthly', '1'),
('challenge_gp', '2500'),
('challenge_gp_int', '10'),
('pcode', ''),
('import_type', '3'),
('import_games', '1'),
('import_limit', '100'),
('auto_publish', '1'),
('avatar_size', '300000'),
('cover_size', '400000'),
('thumb_size', '300000'),
('game_size', '5000000'),
('avatar_allowed', 'png, jpg, gif'),
('cover_allowed', 'png, jpg, gif'),
('thumb_allowed', 'png, jpg, gif'),
('advance_search', '0'),
('search_max', '100'),
('detectlang_api', '');";
			
			$language_dump = "INSERT INTO languages (name, code, country_code, rtl) VALUES ('English', 'en', 'us', 0),			
('Français', 'fr', 'fr', 0),
('Español', 'es', 'es', 0),
('Deutsche', 'de', 'de', 0),
('русский', 'ru', 'ru', 0),
('Latviešu', 'lv', 'lv', 0),
('عَرَبِيّ', 'ar', 'sa', 1),
('한국어', 'ko', 'kr', 0),
('日本語', 'ja', 'jp', 0),
('中文', 'zh', 'cn', 0),
('Dansk', 'da', 'dk', 0),
('Nederlands', 'nl', 'nl', 0),
('Türk', 'tr', 'tr', 0),
('Tiếng Việt', 'vi', 'vn', 0),
('Português', 'pt', 'br', 0),
('Tagalog', 'tl', 'ph', 0);";
				
			$dump = $db->query($settings_dump);
			$dump = $db->query($language_dump); 				 			
			if($install && $dump){
				die("success");
			} else {
				die("error");
			}
		}
	}
} else if(isset($_GET["do"], $_POST["username"], $_POST["email"], $_POST["password"]) && $_GET["do"] == "admin"){
	require '../system/database.php';				
	require '../system/external/password.php';			 	
	require '../system/security.class.php';				 	
	$secure = new Security;
	
	$username = $secure->purify($_POST["username"]);
	$email = $secure->washEmail($_POST["email"]); 	
	$password = password_hash($_POST["password"], PASSWORD_DEFAULT);
	$robohash = rand(1, 3);
	
	$insert = $db->query("INSERT INTO users (position, username, email, password, robohash) VALUES (1, '$username', '$email', '$password', $robohash);");
	
	if($insert){
		die("success");
	} else {
		die("error");
	}
} else if(isset($_GET["do"], $_POST["site_name"], $_POST["site_url"], $_POST["protocol"], $_POST["type"]) && $_GET["do"] == "settings"){
	require '../system/database.php';				 	
	require '../system/security.class.php';				 	
	$secure = new Security;
	
	$site_name = $secure->purify($_POST["site_name"]);
	$site_url = $secure->purify($_POST["site_url"]);
	$protocol = $secure->purify($_POST["protocol"]);
	$type = $secure->purify($_POST["type"]);
	$sidebar_ad = "&lt;h3 class=&quot;page-header text-center&quot;&gt;&lt;i class=&quot;fa fa-money&quot;&gt;&lt;/i&gt; Advertisement&lt;/h3&gt;
&lt;div class=&quot;text-center&quot;&gt;
&lt;img src=&quot;".$site_url."/templates/default/assets/images/300x600.jpg&quot;/&gt;
&lt;/div&gt;";
	$sidebar_ad_play = "&lt;h3 class=&quot;page-header text-center&quot;&gt;&lt;i class=&quot;fa fa-money&quot;&gt;&lt;/i&gt; Advertisement&lt;/h3&gt;
&lt;div class=&quot;text-center&quot;&gt;
&lt;img src=&quot;".$site_url."/templates/default/assets/images/300x600.jpg&quot;/&gt;
&lt;/div&gt;";
	$banner_ad = "&lt;img src=&quot;".$site_url."/templates/default/assets/images/banner.gif&quot;/&gt;";
	$pages_dump = "INSERT INTO `pages` (`id`, `name`, `content`) VALUES
(1, 'User API', '&lt;h2&gt;User API Documentation&lt;/h2&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;You can fetch a user data in json format. &lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;You can create your own plugin to display user related data in your websites like user stats, profile info and more!&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;Here''s the endpoint to fetch a user data:&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;code&gt;".$site_url."/api/user/&lt;strong&gt;username&lt;/strong&gt;&lt;/code&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;Change the &lt;strong&gt;username&lt;/strong&gt; to the user''s username.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;If user was not found, the api will return &lt;em&gt;failed&lt;/em&gt; status.&lt;/span&gt;&lt;/p&gt;'),
(2, 'Game Feed', '&lt;h2&gt;Game Feed Documentation&lt;/h2&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;You can fetch our games and add it to your sites catalog!&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;To view the game feed (JSON format) use this endpoint:&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;&lt;code&gt;".$site_url."/gamefeed&lt;/code&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;By default only 100 games is listed per request, you can fetch all the games by just adding start and limit parameter in the endpoint:&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;&lt;code&gt;".$site_url."/gamefeed/start=200&amp;amp;limit=40&lt;/code&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;The example above will skip the first 200 games and show the rest of it but limited to 40 items&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;If limit parameter is above 100 the feed will still show 100&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&nbsp;&lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-size: 14px;&quot;&gt;It will show &lt;code&gt;&quot;error&quot;&lt;/code&gt; text on failure&lt;/span&gt;&lt;/p&gt;'),
(3, 'Referral System', '&lt;h2&gt;Refer Users and Earn EXP!&lt;/h2&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;Invite your friends and earn exp!&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;All you have to do is to send them your referral link:&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;code&gt;".$site_url."/register/?ref=&lt;strong&gt;username&lt;/strong&gt;&lt;/code&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-family: monospace;&quot;&gt;Change the &lt;strong&gt;username&lt;/strong&gt; to your account''s username.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;font-family: monospace;&quot;&gt;If user has successfully registered, you will earn an exp reward!&lt;/span&gt;&lt;/p&gt;'),
(4, 'Enable Flash Player', '&lt;h1&gt; &lt;/h1&gt;\n&lt;p&gt;1. &lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;In the address bar, type &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;chrome://settings/content&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;img src=&quot;https://helpx.adobe.com/flash-player/kb/enabling-flash-player-chrome/_jcr_content/main-pars/procedure_2/proc_par/step_0/step_par/image_1561986267.img.jpg/win-chrome-1.JPG&quot; alt=&quot;Type chrome://settings/content in the address bar&quot; /&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;2. &lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;On the &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Content settings&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt; screen, find the Flash Player listing. Check the status.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;img src=&quot;https://helpx.adobe.com/flash-player/kb/enabling-flash-player-chrome/_jcr_content/main-pars/procedure_2/proc_par/step_1/step_par/image.img.jpg/win-chrome-2.JPG&quot; alt=&quot;The Content settings screen&quot; /&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;3. &lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;Select &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Allow sites to run Flash&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;, and then click &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Done&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;img src=&quot;https://helpx.adobe.com/flash-player/kb/enabling-flash-player-chrome/_jcr_content/main-pars/procedure_2/proc_par/step_2/step_par/image.img.jpg/win-chrome-3.JPG&quot; alt=&quot;The Flash section of the Content settings screen&quot; /&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;4. &lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;To manage Flash Player settings by site, click &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Manage exceptions&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;&lt;img src=&quot;https://helpx.adobe.com/flash-player/kb/enabling-flash-player-chrome/_jcr_content/main-pars/procedure_2/proc_par/step_3/step_par/image.img.jpg/win-chrome-4.JPG&quot; alt=&quot;&quot; /&gt;&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;5. &lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;On the &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Flash exceptions&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt; screen, enter the website domain and then choose &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Allow&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;.  When finished adding sites, click &lt;/span&gt;&lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-size: 16px; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; box-sizing: border-box; color: #333333; line-height: 24px;&quot;&gt;Done&lt;/span&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;\n&lt;p&gt;&lt;img src=&quot;https://helpx.adobe.com/flash-player/kb/enabling-flash-player-chrome/_jcr_content/main-pars/procedure_2/proc_par/step_4/step_par/image.img.jpg/win-chrome-5.JPG&quot; alt=&quot;The Flash exceptions screen&quot; /&gt;&lt;/p&gt;\n&lt;p&gt; &lt;/p&gt;\n&lt;p&gt;&lt;span style=&quot;color: #333333; font-family: adobe-clean, HelveticaNeue-light, \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px;&quot;&gt;6. &lt;/span&gt;Close the &lt;span class=&quot;uicontrol&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; outline: 0px; font-weight: bold; font-style: inherit; font-family: inherit; box-sizing: border-box;&quot;&gt;Content settings&lt;/span&gt; screen.&lt;/p&gt;');";

	$update = $db->query("UPDATE settings SET value = '$site_name' WHERE name = 'site_name' LIMIT 1");
	$update = $db->query("UPDATE settings SET value = '$site_url' WHERE name = 'site_url' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$protocol' WHERE name = 'protocol' LIMIT 1"); 	
	$update = $db->query("UPDATE settings SET value = '$sidebar_ad' WHERE name = 'widget_sidebar_global' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$sidebar_ad_play' WHERE name = 'widget_sidebar_play' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$banner_ad' WHERE name = 'widget_banner_top' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$banner_ad' WHERE name = 'widget_banner_bottom' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$banner_ad' WHERE name = 'widget_banner_play' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$banner_ad' WHERE name = 'game_banner_top' LIMIT 1"); 
	$update = $db->query("UPDATE settings SET value = '$banner_ad' WHERE name = 'game_banner_bottom' LIMIT 1"); 
	$dump = $db->query($pages_dump);
	$_SESSION["protocol"] = $protocol;
	$_SESSION["type"] = $type;
		
	if($update && $dump){
		die("success");
	} else {
		die("error");
	}
} else {
	die("error");
}

/* End */
?>