<?php
/**
 * Arcadia - Arcade Gaming Platform
 * @author Norielle Cruz <http://noriellecruz.com>
 */
 
 /**
  * Start Session
  */
  
  session_start();
 
 /**
  * Require Database
  */
  
  require '../system/database.php';
  
 /**
  * Require System Class
  */
  
  require '../system/sys.class.php';  
  
  $sys = new System;
  
 /**
  * Require Security Class
  */
  
  require '../system/security.class.php';
  
  $secure = new Security;
  
 /**
  * Arcadia Default Games Importer
  * @source Gamepix <http://gamepix.com>
  * @source Kongregate <http://kongregate.com>
  * @source ScirraArcade <http://scirra.com>
  * @source Spilgames <http://spilgames.com>
  */
  
  if(isset($_GET["name"], $_GET["source"])){
  	$data_id = $_GET["name"];
  	$source_name = $_GET["source"];  	
  } else {
  	$data_id = "scirra_1";
  	$source_name = "sa";  	
  }
  
  if(!file_exists("games/".$data_id.".install")){
  	die("error");  	
  }
  
  if($source_name !== "kg"){
  	$get = json_decode(file_get_contents("games/".$data_id.".install"), true);
  } else {
  	$get = file_get_contents("games/".$data_id.".install");  	
  }
  
  if($_SESSION["protocol"] == 2){
  /**
   * Import Scirra Arcade Games
   */
    
  if($source_name == "sa"){
  	shuffle($get["games"]); 	
  	foreach($get["games"] as $game){
  		$id = $game['id']."_sa";
  		$type = 1;
  		$title = $game['name'];
  		$status = 1;
  		$category = ucfirst(str_replace(" Games", "", $game["categoryName"]));
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));
  		$source = $game["iframeURL"];
  		if($game["width"] < 450){
  			$width = 450;
  		} else {
  			$width = $game["width"];  			
  		}
  		if($game["height"] < 400){
  			$height = 400;
  		} else {
  			$height = $game["height"];  			
  		}
  		$desc = $secure->purify($game["longDescription"]);
  		if($game["mobileEnabled"] == true){
  			$mobile = 1;  			
  		} else {
  			$mobile = 0;  		  			
  		}
  		$thumb = $game["gameImageURL"];
  		$help = $secure->purify($game["instructions"]);
  		$plays = mt_rand(1, 30000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			
  		}  		
  	}	
  	  	
  	if(!isset($_GET["next"])){
  		$sys->go("games.php?name=scirra_2&source=sa&next=2");  		
  	}
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 2){
  		$sys->go("games.php?name=scirra_3&source=sa&next=3");  		
  	}
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 3){
  		$sys->go("games.php?name=scirra_4&source=sa&next=4");  		
  	}  
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 4){
  		$sys->go("games.php?name=scirra_5&source=sa&next=5");  		
  	}  		
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 5){
  		$sys->go("games.php?name=kg&source=kg");  
  	}    	  				 	 	
  }
  
  /**
   * Import Kongregate Games
   */
  
  if($source_name == "kg" && $_SESSION["type"] == 2){
  	$get_kg = simplexml_load_string($get);  	
  	foreach($get_kg as $game){
  		$id = $game->id."_kg";
  		$type = 2;
  		$title = $game->title;
  		$status = 1;
  		$arr_cat = explode(" & ", $game->category);
  		if(empty($arr_cat[0])){
  			$category = ucfirst($game->category);
  		} else {
  			$category = ucfirst($arr_cat[0]);
  		}
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));  		
  		$source = str_replace("http://external.kongregate-games.com", "https://chat.kongregate.com", $game->flash_file);
  		if($game->width < 450){
  			$width = 450;
  		} else {
  			$width = $game->width;  			
  		}
  		if($game->height < 400){
  			$height = 400;
  		} else {
  			$height = $game->height;  			
  		}
  		$desc = $secure->purify($game->description);
  		$mobile = 0;  		 
  		$thumb = $game->thumbnail;
  		$help = $secure->purify($game->instructions);
  		$plays = mt_rand(1, 6000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			
  		}  		
  	}	
  	
  	if(isset($_GET["source"]) && $_GET["source"] == "kg"){
  		$sys->go("games.php?name=gp&source=gp");  		
  	}  	  		 	  	  	  
  } else {
  	if(isset($_GET["source"]) && $_GET["source"] == "kg"){
  		$sys->go("games.php?name=gp&source=gp");  		
  	}  	  		 	  	  	  	
  }
  
  /**
   * Import Gamepix Games
   */
    
  if($source_name == "gp"){
  	shuffle($get["data"]); 	
  	foreach($get["data"] as $game){
  		$id = $game['id']."_gp";
  		$type = 1;
  		$title = $game['title'];
  		$status = 1;
  		$category = ucfirst($game["category"]);
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));  		
  		$source = str_replace("http://", "https://", $game["url"]);
  		if($game["width"] < 450){
  			$width = 450;
  		} else {
  			$width = $game["width"];  			
  		}
  		if($game["height"] < 400){
  			$height = 400;
  		} else {
  			$height = $game["height"];  			
  		}
  		$desc = $secure->purify($game["description"]);
  		if($game["touch"] == true){
  			$mobile = 1;  			
  		} else {
  			$mobile = 0;  		  			
  		}
  		$thumb = $game["thumbnailUrl"];
  		$help = $secure->purify($game["description"]);
  		$plays = mt_rand(1, 6000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			
  		}  		
  	}	
  	
  	if(isset($_GET["source"]) && $_GET["source"] == "gp"){
  		session_unset();
  		die("success");
  	}  	  		 	  	  	  	
  }
   
  } else {
  	
  /**
   * Import Scirra Arcade Games
   */
    
  if($source_name == "sa"){
  	shuffle($get["games"]); 	
  	foreach($get["games"] as $game){
  		$id = $game['id']."_sa";
  		$type = 1;
  		$title = $game['name'];
  		$status = 1;
  		$category = ucfirst(str_replace(" Games", "", $game["categoryName"]));
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));  		
  		$source = $game["iframeURL"];
  		if($game["width"] < 450){
  			$width = 450;
  		} else {
  			$width = $game["width"];  			
  		}
  		if($game["height"] < 400){
  			$height = 400;
  		} else {
  			$height = $game["height"];  			
  		}
  		$desc = $secure->purify($game["longDescription"]);
  		if($game["mobileEnabled"] == true){
  			$mobile = 1;  			
  		} else {
  			$mobile = 0;  		  			
  		}
  		$thumb = $game["gameImageURL"];
  		$help = $secure->purify($game["instructions"]);
  		$plays = mt_rand(1, 6000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			
  		}  		
  	}	
  	  	
  	if(!isset($_GET["next"])){
  		$sys->go("games.php?name=scirra_2&source=sa&next=2");  		
  	}
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 2){
  		$sys->go("games.php?name=scirra_3&source=sa&next=3");  		
  	}
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 3){
  		$sys->go("games.php?name=scirra_4&source=sa&next=4");  		
  	}  
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 4){
  		$sys->go("games.php?name=scirra_5&source=sa&next=5");  		
  	}  		
  	  	
  	if(isset($_GET["next"]) && $_GET["next"] == 5){
  		$sys->go("games.php?name=sp1&source=sp&next=1");  
  	}    	  				 	 	
  }

  /**
   * Import Spilgames
   */
    
  if($source_name == "sp"){
  	shuffle($get["entries"]); 	
  	foreach($get["entries"] as $game){
  		$id = $game['id']."_sp";
  		if(strpos($game["gameUrl"], "/flash/")){
  			$type = 2;
  		} else {
  			$type = 1;
  		}
  		$title = $game['title'];
  		$status = 1;
  		if(empty($game["category"])){
  			$category = "Other";
  		} else {
  			$category = $game["category"];
  		}
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));  		
  		$source = $game["gameUrl"];
  		if($game["width"] < 450){
  			$width = 450;
  		} else {
  			$width = $game["width"];  			
  		}
  		if($game["height"] < 400){
  			$height = 400;
  		} else {
  			$height = $game["height"];  			
  		}
  		$desc = $secure->purify($game["description"]);
  		if(strpos($game["gameUrl"], "/flash/")){
  			$mobile = 0;
  		} else {
  			$mobile = 1;
  		}
  		$thumb = $game["thumbnails"]["large"];
  		$help = $secure->purify($game["description"]);
  		$plays = mt_rand(1, 6000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			if($_SESSION["type"] == 1){
  				if(!strpos($source, "/flash/")){
  					$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			  					
  				}
  			} else {
  				$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  		  				
  			}
  		}
  	}	
  	  	
  	if(isset($_GET["next"]) && $_GET["next"] == 1){
  		$sys->go("games.php?name=sp2&source=sp&next=2");  		
  	}
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 2){
  		$sys->go("games.php?name=sp3&source=sp&next=3");  		
  	}  	
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 3){
  		$sys->go("games.php?name=sp4&source=sp&next=4");  		
  	}  	
  	
  	if(isset($_GET["next"]) && $_GET["next"] == 4){
  		$sys->go("games.php?name=sp5&source=sp&next=5");  		
  	}  	  	  	
  	  	  	
  	if(isset($_GET["next"]) && $_GET["next"] == 5){
  		$sys->go("games.php?name=kg&source=kg");  
  	}    	  				 	 	
  }  
  
  /**
   * Import Kongregate Games
   */
  
  if($source_name == "kg" && $_SESSION["type"] == 2){
  	$get_kg = simplexml_load_string($get);  	
  	foreach($get_kg as $game){
  		$id = $game->id."_kg";
  		$type = 2;
  		$title = $game->title;
  		$status = 1;
  		$arr_cat = explode(" & ", $game->category);
  		if(empty($arr_cat[0])){
  			$category = ucfirst($game->category);
  		} else {
  			$category = ucfirst($arr_cat[0]);
  		}
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));  		
  		$source = str_replace("http://external.kongregate-games.com", "https://chat.kongregate.com", $game->flash_file);
  		if($game->width < 450){
  			$width = 450;
  		} else {
  			$width = $game->width;  			
  		}
  		if($game->height < 400){
  			$height = 400;
  		} else {
  			$height = $game->height;  			
  		}
  		$desc = $secure->purify($game->description);
  		$mobile = 0;  		 
  		$thumb = $game->thumbnail;
  		$help = $secure->purify($game->instructions);
  		$plays = mt_rand(1, 6000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			
  		}  		
  	}	
  	
  	if(isset($_GET["source"]) && $_GET["source"] == "kg"){
  		$sys->go("games.php?name=gp&source=gp");  		
  	}  	  		 	  	  	  
  } else {
  	if(isset($_GET["source"]) && $_GET["source"] == "kg"){
  		$sys->go("games.php?name=gp&source=gp");  		
  	}  	  		 	  	  	  	
  }
  
  /**
   * Import Gamepix Games
   */
    
  if($source_name == "gp"){
  	shuffle($get["data"]); 	
  	foreach($get["data"] as $game){
  		$id = $game['id']."_gp";
  		$type = 1;
  		$title = $game['title'];
  		$status = 1;
  		$category = ucfirst($game["category"]);
  		$unique_id = strtolower(str_replace(" ", "_", str_replace("-", " ", $category)));  		
  		$source = str_replace("http://", "https://", $game["url"]);
  		if($game["width"] < 450){
  			$width = 450;
  		} else {
  			$width = $game["width"];  			
  		}
  		if($game["height"] < 400){
  			$height = 400;
  		} else {
  			$height = $game["height"];  			
  		}
  		$desc = $secure->purify($game["description"]);
  		if($game["touch"] == true){
  			$mobile = 1;  			
  		} else {
  			$mobile = 0;  		  			
  		}
  		$thumb = $game["thumbnailUrl"];
  		$help = $secure->purify($game["description"]);
  		$plays = mt_rand(1, 6000);
  		
  		$check_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		
  		if($check_cat->num_rows < 1){
  			$cat_desc = "Play tons of ".$category." games for free! Earn EXP and climb the leaderboard!";
  			$db->query("INSERT INTO categories (unique_id, name, description) VALUES ('$unique_id', '$category', '$cat_desc');");  			
  		}
  		
  		$find_cat = $db->query("SELECT * FROM categories WHERE unique_id = '$unique_id' LIMIT 1");
  		$cat_id = $find_cat->fetch_assoc();
  		
  		$unique = $db->query("SELECT * FROM games WHERE unique_id = '$id'");
  		
  		if($unique->num_rows < 1){
  			$insert = $db->query("INSERT INTO games (unique_id, uid, name, status, category, source, description, thumb, width, height, type, mobile, help, plays) VALUES ('$id', 1, '$title', '$status', '".$cat_id["id"]."', '$source', '$desc', '$thumb', '$width', '$height', '$type', '$mobile', '$help', '$plays');");  			
  		}  		
  	}	
  	
  	if(isset($_GET["source"]) && $_GET["source"] == "gp"){
  		session_unset();  		
  		die("success");
  	}  	  		 	  	  	  	
  }
  }

/* End */
?>