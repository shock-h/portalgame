<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link rel="icon" type="image/png" href="../templates/default/assets/images/favicon.png">	

    <title>Arcadia Installer</title>

    <!-- Fonts and Icons -->  
    <link href='//fonts.googleapis.com/css?family=Quicksand' rel='stylesheet' type='text/css'>
    <link href="../templates/default/assets/css/nprogress.min.css" rel="stylesheet">  
    <link href="../templates/default/assets/css/font-awesome.min.css" rel="stylesheet">       

    <!-- Stylesheets -->
    <link href="../templates/default/assets/css/bootstrap.min.css" rel='stylesheet'>
    <link href="../templates/default/assets/css/sweetalert.min.css" rel="stylesheet">    
    <link href="../templates/default/assets/css/animate.min.css" rel="stylesheet">
    <link href="../templates/default/assets/css/style.min.css" rel='stylesheet'>
    <link href="../templates/default/assets/css/colors/default.css" rel='stylesheet'> 
    
    <!-- Scripts -->
    <script src="../system/libs/jquery.min.js"></script>
    <script src="../templates/default/assets/js/nprogress.min.js"></script> 	 			
</head>

<body>
<div class="header">
			<div class="logo">
				<h1>
				<div style="text-transform: uppercase" class="animated bounce">Arcadia</div>
				<span class="animated zoomIn">Arcade Gaming Platform</span>
				</h1>
			</div>
</div>

<br /><br />

<div class="container wrapper">
	<div class="banner-top animated bounceIn">
	<?php if(!isset($_GET["next"])){ ?>
		<h3>Server Check</h3>
		<h4>Installer<label>/</label>Server Check</h4>
	<?php } ?>
	<?php if(isset($_GET["next"]) && $_GET["next"] == "database"){ ?>
		<h3>Database</h3>
		<h4>Installer<label>/</label>Database</h4>
	<?php } ?> 	
	<?php if(isset($_GET["next"]) && $_GET["next"] == "admin"){ ?>
		<h3>Admin Account</h3>
		<h4>Installer<label>/</label>Admin Account</h4>
	<?php } ?> 	 	 	
	<?php if(isset($_GET["next"]) && $_GET["next"] == "settings"){ ?>
		<h3>Site Settings</h3>
		<h4>Installer<label>/</label>Site Settings</h4>
	<?php } ?> 	 	
	<?php if(isset($_GET["next"]) && $_GET["next"] == "games"){ ?>
		<h3>Import Games</h3>
		<h4>Installer<label>/</label>Import Games</h4>
	<?php } ?> 	 	
	</div>

<?php if(!isset($_GET["next"])){ ?>
	<div class="product">
		<div class="spec">
			<img src="https://www.storetutorshd20.com.br/wp-content/uploads/2017/05/logo-1.png"><h3>Server Check</h3>
		</div>

		<div class="main-arcadia">
				<div class="form-arcadia text-center">
				   <div class="alert alert-success">
				   <p class="lead"><i class="fa fa-info-circle"></i> Click the button below to check server requirements!</p>
				   </div>
						<button type="button" class="btn btn-lg btn-success check-server"><i class="fa fa-check"></i> Check</button>								
					<br />
				</div>
			</div>
		</div>
<?php } ?>
		
<?php if(isset($_GET["next"]) && $_GET["next"] == "database"){ ?>
	<div class="product">
		<div class="spec">
			<h3>Database</h3>
		</div>

		<div class="main-arcadia">
				<div class="form-arcadia">
				   <form id="database">
				   <div class="form-group">
				   <i class="fa fa-globe"></i> Database Host <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The host link of your database, ex: localhost, db1.dbserver.com ..,,etc"><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="text"	name="host" class="form-control host" placeholder="Database Host">
				   </div>
				   <div class="form-group">
				   <i class="fa fa-database"></i> Database Name <help class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The name of your database."><i class="fa fa-question-circle"></i>
         </help> 				   
				   <input type="text"	name="name" class="form-control name" placeholder="Database Name">
				   </div>
				   <div class="form-group">
				   <i class="fa fa-key"></i> Database Username <span class="help_btn" data-toggle="tooltip" data-placement="right" title="The username for your database."><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="text"	name="username" class="form-control username" placeholder="Database Username">
				   </div>
				   <div class="form-group">
				   <i class="fa fa-lock"></i> Database Password <span class="help_btn" data-toggle="tooltip" data-placement="right" title="The password for your database."><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="text"	name="password" class="form-control password" placeholder="Database Password">
				   </div> 				    				    				   
						<button type="submit" class="btn btn-md btn-success submit-btn"><i class="fa fa-check"></i> Submit</button>								
						</form>
					<br />
				</div>
			</div>
		</div>
<?php } ?>		

<?php if(isset($_GET["next"]) && $_GET["next"] == "admin"){ ?>
	<div class="product">
		<div class="spec">
			<h3>Admin Account</h3>
		</div>

		<div class="main-arcadia">
				<div class="form-arcadia">
				   <form id="admin">
				   <div class="form-group">
				   <i class="fa fa-user"></i> Admin Username <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The admin username."><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="text"	name="username" class="form-control username" placeholder="Username">
				   </div>
				   <div class="form-group">
				   <i class="fa fa-envelope"></i> Admin Email <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The admin email."><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="email"	name="email" class="form-control email" placeholder="Email Address">
				   </div> 				   
				   <div class="form-group">
				   <i class="fa fa-lock"></i> Admin Password <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The admin password."><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="password"	name="password" class="form-control password" placeholder="Password">
				   </div>	    				    				   
						<button type="submit" class="btn btn-md btn-success submit-btn"><i class="fa fa-check"></i> Submit</button>								
						</form> 	
					<br />
				</div>
			</div>
		</div> 		
<?php } ?>		

<?php if(isset($_GET["next"]) && $_GET["next"] == "settings"){ ?>
	<div class="product">
		<div class="spec">
			<h3>Site Settings</h3>
		</div>

		<div class="main-arcadia">
				<div class="form-arcadia">
				   <form id="settings">
				   <div class="form-group">
				   <i class="fa fa-cog"></i> Site Name <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The site name."><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="text"	name="site_name" class="form-control site_name" placeholder="Site Name">
				   </div>
				   <div class="form-group">
				   <i class="fa fa-cog"></i> Site URL <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Required. The install location of the script, don't add trailing / at the end! ex: http://mydomain.com or http://mydomain.com/installfolder"><i class="fa fa-question-circle"></i>
         </span> 				   
				   <input type="text"	name="site_url" class="form-control site_url" placeholder="Site URL">
				   </div>	    				   
				   <div class="form-group">
				   <i class="fa fa-cog"></i> Site Protocol <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Choose what type of protocol you will be using for your site. You won't be able to change this after installation! Please choose carefully! Choosing (https) will affect the number of default games to be installed because games with with (http) protocol will not be added."><i class="fa fa-question-circle"></i>
         </span> 				   
         <select name="protocol" class="form-control">
          <option value="1" selected>HTTP Protocol (Normal)</option>
          <option value="2">HTTPS Protocol (Secure)</option>
         </select>
				   </div>	    			
				   <div class="form-group">
				   <i class="fa fa-cog"></i> Game Type <span class="help_btn" data-toggle="tooltip" data-placement="right" title="Choose what type of games you want to be added by the default games importer on the next step. Selecting only flash games is not recommended! So it's not added in the selection."><i class="fa fa-question-circle"></i>
         </span> 				   
         <select name="type" class="form-control">
          <option value="1">HTML5 Games</option>
          <option value="2" selected>HTML5 & Flash Games</option>
         </select>
				   </div>	    			 				   	   				   
						<button type="submit" class="btn btn-md btn-success submit-btn"><i class="fa fa-check"></i> Submit</button>								
						</form>
					<br />
				</div>
			</div>
		</div> 		
<?php } ?>		

<?php if(isset($_GET["next"]) && $_GET["next"] == "games"){ ?>
	<div class="product">
		<div class="spec">
			<h3>Import Games</h3>
		</div>

		<div class="main-arcadia">
				<div class="form-arcadia text-center">
				   <div class="alert alert-success">
				   <p class="lead"><i class="fa fa-info-circle"></i> Let's import the default games!<br />Click the button below to start!</p>
				   </div>
						<button type="button" class="btn btn-lg btn-success submit-btn import-games"><i class="fa fa-upload"></i> Import</button>
					<br />
				</div>
			</div>
		</div> 		
<?php } ?>		
		
		<br />
	<br />
</div>

<div class="footer">
	<div class="container">
		
			<div class="footer-bottom">
				<h2 style="color: white">
				<logo style="text-transform: uppercase">Arcadia</logo>
				<span>Arcade Gaming Platform</span>
				</h2>
			</div>
		<div class="copy-right">
			<p>&copy; <?php echo date("Y"); ?> Arcadia. All Rights Reserved.</p>
		</div>
	</div>
</div>

<script src="../templates/default/assets/js/bootstrap.min.js"></script>
<script src="../templates/default/assets/js/sweetalert.min.js"></script>
<script src="install.js"></script>
</body>
</html>