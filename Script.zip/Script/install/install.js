$(document).ready(function(){
	NProgress.start();
	$('[data-toggle="tooltip"]').tooltip(); 	
	swal.setDefaults({
		customClass: "animated bounceIn",
		confirmButtonText: "Continue",
		confirmButtonColor: "#FAB005", 		
		html: true					
	});  		
	setTimeout(function() {
		NProgress.done();	
	}, 1000);
});
  
$(".check-server").click(function(e){
	e.preventDefault();
	$("button").html('<i class="fa fa-spinner fa-spin"></i> Checking');
	$("button, input").attr("disabled");
	$.ajax({
		url: "process.php?do=check",
		success: function(result){
			$("button").html('<i class="fa fa-check"></i> Check');
			$("button, input").removeAttr("disabled"); 			
			swal({
			title: '<i class="fa fa-info-circle"></i> Check Results', 
			text: result,
			showCancelButton: true,
			closeOnConfirm: false
			}, function(isConfirm){
				if(isConfirm){
					document.location.href = "?next=database";
				}
			});
		}
	});
});

$("#database").submit(function(e){
	e.preventDefault();
	$.ajax({
		url: "process.php?do=database",
		type: "POST",
		data: new FormData(this),
		contentType: false,
		cache: false,
		processData: false,
		beforeSend: function(){
			var host = $(".host").val();
			var name = $(".name").val(); 			 		
			
			if(host == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Host Empty!', "Database host is a required field!");
				return false;
			}
			
			if(name == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Name Empty!', "Database name is a required field!");
				return false;
			}
			
			$("button").html('<i class="fa fa-spinner fa-spin"></i> Please Wait');
			$("button, input").attr("disabled"); 			
		},
		success: function(result){
			if(result == "success"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			 			
				swal({
					title: '<i class="fa fa-check"></i> Database Installed!', 
					text: "Database has been installed!",
					closeOnConfirm: false 					
				}, function(isConfirm){
					if(isConfirm){
						document.location.href = "?next=admin";
					}
				});
			}

			if(result == "invalid"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			
				swal('<i class="fa fa-exclamation-circle"></i> Invalid!', "The database credentials you entered are invalid!");		
			}
			
			if(result == "error"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			
				swal('<i class="fa fa-exclamation-circle"></i> Error!', "Something went wrong!");		
			}
		}
	});
});

$("#admin").submit(function(e){
	e.preventDefault();
	$.ajax({
		url: "process.php?do=admin",
		type: "POST",
		data: new FormData(this),
		contentType: false,
		cache: false,
		processData: false,
		beforeSend: function(){
			var username = $(".username").val();
			var email = $(".email").val(); 	
			var password = $(".password").val(); 	 					 		
			
			if(username == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Username Empty!', "Admin username is a required field!");
				return false;
			}
			
			if(email == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Email Empty!', "Admin email is a required field!");
				return false;
			}
			
			if(password == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Password Empty!', "Admin password is a required field!");
				return false;
			} 			
			
			$("button").html('<i class="fa fa-spinner fa-spin"></i> Please Wait');
			$("button, input").attr("disabled"); 			
		},
		success: function(result){			
			if(result == "success"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			 			
				swal({
					title: '<i class="fa fa-check"></i> Admin Created!', 
					text: "Admin account has been created!",
					closeOnConfirm: false 					
				}, function(isConfirm){
					if(isConfirm){
						document.location.href = "?next=settings";
					}
				});
			}
			
			if(result == "error"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			
				swal('<i class="fa fa-exclamation-circle"></i> Error!', "Something went wrong!");		
			}
		}
	});
});

$("#settings").submit(function(e){
	e.preventDefault();
	$.ajax({
		url: "process.php?do=settings",
		type: "POST",
		data: new FormData(this),
		contentType: false,
		cache: false,
		processData: false,
		beforeSend: function(){
			var site_name = $(".site_name").val();
			var site_url = $(".site_ur").val(); 			 		
			
			if(site_name == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Site Name Empty!', "Site name is a required field!");
				return false;
			}
			
			if(site_url == ""){
				swal('<i class="fa fa-exclamation-circle"></i> Site URL Empty!', "Site URL is a required field!");
				return false;
			}
			
			$("button").html('<i class="fa fa-spinner fa-spin"></i> Please Wait');
			$("button, input").attr("disabled"); 			
		},
		success: function(result){
			if(result == "success"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			 			
				swal({
					title: '<i class="fa fa-check"></i> Settings Saved!', 
					text: "System settings has been saved!",
					closeOnConfirm: false 					
				}, function(isConfirm){
					if(isConfirm){
						document.location.href = "?next=games";
					}
				});
			}
			
			if(result == "error"){
				$("button").html('<i class="fa fa-check"></i> Submit');
				$("button, input").removeAttr("disabled"); 			
				swal('<i class="fa fa-exclamation-circle"></i> Error!', "Something went wrong!");		
			}
		}
	});
});

$(".import-games").click(function(e){
	e.preventDefault();
	$("button").html('<i class="fa fa-spinner fa-spin"></i> Importing');
	$("button, input").attr("disabled");
	$.ajax({
		url: "games.php",
		success: function(result){
			$("button").html('<i class="fa fa-check"></i> Import');
			$("button, input").removeAttr("disabled"); 			
			if(result == "success"){
				swal({
					title: "<i class='fa fa-check'></i> Congratulations!",
					text: "Arcadia Installation Complete!<br />Default arcade games has been imported!<br />Please delete the <b>install</b> folder!<br />For security reasons<br />Chmod <strong>system/config.php</strong> to 644",
					confirmButtonText: "Finish",
					closeOnConfirm: false
				}, function(isConfirm){
					if(isConfirm){
						document.location.href = "/";
					}
				});
			}
			
			if(result == "error"){
				swal("<i class='fa fa-exclamation-circle'></i> Error!", "Error occured while importing games!");
			}
		}
	});
});