<div class="shoutbox animated rubberBand">
<div class="shoutbox_header">
 <i class="fa fa-bullhorn"></i> <?php echo $lang["parts_head_shoutbox"]; ?> (<span class="online-users">0</span> <i class="fa fa-users"></i>)
 <span class="toggle_btn pull-right"><i class="fa fa-window-maximize"></i></span>
</div>
  <div class="toggle_chat">
  <div class="message_box"></div>
    <div class="user_info">
   <input type="text" name="shout_message" id="shout_message" maxlength="100" placeholder="<?php echo $lang['placeholder_shoutbox']; ?>">
    </div>
  </div>
</div>