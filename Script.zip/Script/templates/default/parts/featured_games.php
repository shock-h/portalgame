<?php
$cats = explode(",", str_replace(" ", "", $get->system("featured")));
if(!isset($cats[0])){
	$cats[0] = 1;
} else if (!$secure->isNumber($cats[0])) {
	$cats[0] = 1;
}
$cat1 = $db->query("SELECT name FROM categories WHERE id = " . $cats[0] . " LIMIT 1");
$cat1data = $cat1->fetch_assoc();
if(!isset($cats[1])){
	$cats[1] = 2;
} else if (!$secure->isNumber($cats[1])) {
	$cats[1] = 2;
}
$cat2 = $db->query("SELECT name FROM categories WHERE id = " . $cats[1] . " LIMIT 1");
$cat2data = $cat2->fetch_assoc();
if(!isset($cats[2])){
	$cats[2] = 3;
} else if (!$secure->isNumber($cats[2])) {
	$cats[2] = 3;
}
$cat3 = $db->query("SELECT name FROM categories WHERE id = " . $cats[2] . " LIMIT 1");
$cat3data = $cat3->fetch_assoc();
if(!isset($cats[3])){
	$cats[3] = 4;
} else if (!$secure->isNumber($cats[3])) {
	$cats[3] = 4;
}
$cat4 = $db->query("SELECT name FROM categories WHERE id = " . $cats[3] . " LIMIT 1");
$cat4data = $cat4->fetch_assoc();
?>
<div class="product" id="featured">
		<div class="spec">
			<h3><?php echo $lang["home_head_featuredgames"]; ?></h3>
		</div>
			<div class="tab-head">
				<nav class="nav-sidebar">
					<ul class="nav tabs">
					  <li class="active"><a href="#tab1" data-toggle="tab"><?php echo $cat1data["name"]; ?></a></li>
					  <li><a href="#tab2" data-toggle="tab"><?php echo $cat2data["name"]; ?></a></li> 
					  <li><a href="#tab3" data-toggle="tab"><?php echo $cat3data["name"]; ?></a></li>  
					  <li><a href="#tab4" data-toggle="tab"><?php echo $cat4data["name"]; ?></a></li>
					</ul>
				</nav>
				
				<div class="tab-content">
				
					<div class="tab-pane active" id="tab1">					
					<?php
					$category = $cats[0];
					$limit = $get->system("featured_limit");
					if ($check->isMobile()) {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category AND mobile = 1 ORDER BY plays DESC LIMIT $limit");
					} else {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category ORDER BY plays DESC LIMIT $limit");
					}
					while ($data = $fetch_games->fetch_assoc()) {
						$game = $get->game($data["id"], $get->system("smart_cache"));
						$rating = $get->gameStars($game["plays"]);
						$thumb = $get->thumb($game["thumb"], $game["name"], $secure, $get);
						echo '<div class="col-md-3 pro-1 wow bounceIn gameDesc" data-tipso="'.$game["description"].'">
													<div class="col-m">
													<a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html" class="game-img">
															' . $thumb . '
															<div class="glabel"><p><span class="animated infinite pulse"><i class="fa fa-star"></i> '.$lang["label_featured"].'</span></p></div> 	 										
														</a>
														<div class="mid-1">
															<div class="text-center">
																<h6><a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html">' . $game["name"] . '</a></h6>
															</div>
															<div class="mid-2">
															  <div class="text-center stars">
															  ' . $rating . '
																</div>
																<div class="clearfix"></div>
															</div>
														</div>
													</div>
												</div>';
					}
					?>						
					</div>
					
					<div class="tab-pane" id="tab2">					
					<?php
					$category = $cats[1];
					if ($check->isMobile()) {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category AND mobile = 1 ORDER BY plays DESC LIMIT $limit");
					} else {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category ORDER BY plays DESC LIMIT $limit");
					}
					while ($data = $fetch_games->fetch_assoc()) {
						$game = $get->game($data["id"], $get->system("smart_cache"));
						$rating = $get->gameStars($game["plays"]);
						$thumb = $get->thumb($game["thumb"], $game["name"], $secure, $get);
						echo '<div class="col-md-3 pro-1 animated bounceIn gameDesc" data-tipso="'.$game["description"].'">
													<div class="col-m">
													<a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html" class="game-img">	
															' . $thumb . '
															<div class="glabel"><p><span class="animated infinite pulse"><i class="fa fa-star"></i> '.$lang["label_featured"].'</span></p></div> 	 					 										
														</a>
														<div class="mid-1">
															<div class="text-center">
																<h6><a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html">' . $game["name"] . '</a></h6>
															</div>
															<div class="mid-2">
															  <div class="text-center stars">
															  ' . $rating . '
																</div>
																<div class="clearfix"></div>
															</div>
														</div>
													</div>
												</div>';
					}
					?>
					</div>
					
					<div class="tab-pane" id="tab3">		
					<?php
					$category = $cats[2];
					if ($check->isMobile()) {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category AND mobile = 1 ORDER BY plays DESC LIMIT $limit");
					} else {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category ORDER BY plays DESC LIMIT $limit");
					}
					while ($data = $fetch_games->fetch_assoc()) {
						$game = $get->game($data["id"], $get->system("smart_cache"));
						$rating = $get->gameStars($game["plays"]);
						$thumb = $get->thumb($game["thumb"], $game["name"], $secure, $get);
						echo '<div class="col-md-3 pro-1 animated bounceIn gameDesc" data-tipso="'.$game["description"].'">
													<div class="col-m">
													<a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html" class="game-img">	
															' . $thumb . '
															<div class="glabel"><p><span class="animated infinite pulse"><i class="fa fa-star"></i> '.$lang["label_featured"].'</span></p></div> 	 					 										
														</a>
														<div class="mid-1">
															<div class="text-center">
																<h6><a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html">' . $game["name"] . '</a></h6>		
															</div>
															<div class="mid-2">
															  <div class="text-center stars">
															  ' . $rating . '
																</div>
																<div class="clearfix"></div>
															</div>
														</div>
													</div>
												</div>';
					}
					?>
					</div>
					
					<div class="tab-pane" id="tab4">		
					<?php
					$category = $cats[3];
					if ($check->isMobile()) {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category AND mobile = 1 ORDER BY plays DESC LIMIT $limit");
					} else {
						$fetch_games = $db->query("SELECT id FROM games WHERE status = 1 AND category = $category ORDER BY plays DESC LIMIT $limit");
					}
					while ($data = $fetch_games->fetch_assoc()) {
						$game = $get->game($data["id"], $get->system("smart_cache"));
						$rating = $get->gameStars($game["plays"]);
						$thumb = $get->thumb($game["thumb"], $game["name"], $secure, $get);
						echo '<div class="col-md-3 pro-1 animated bounceIn gameDesc" data-tipso="'.$game["description"].'">
													<div class="col-m">
													<a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html" class="game-img">
														<span class="gamepad"></span>	
															' . $thumb . '
															<div class="glabel"><p><span class="animated infinite pulse"><i class="fa fa-star"></i> '.$lang["label_featured"].'</span></p></div> 	 					 										
														</a>
														<div class="mid-1">
															<div class="text-center">
																<h6><a href="' . $get->system("site_url") . "/play/" . $secure->washName($game["name"]) . "-" . $game["id"] . '.html">' . $game["name"] . '</a></h6>
															</div>
															<div class="mid-2">
															  <div class="text-center stars">
															  ' . $rating . '
																</div>
																<div class="clearfix"></div>
															</div>
														</div>
													</div>
												</div>';
					}
					?>		
					</div>							
			</div>					
	</div>
</div>