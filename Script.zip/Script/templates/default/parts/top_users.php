	<div class="product">
			<div class="spec">
				<h3><?php echo $lang["home_head_topusers"]; ?></h3>
			</div>
			
				<?php
				
				$limit = $get->system("topusers_limit");
				
				$start = 1;
				
				$fetch_topusers = $db->query("SELECT id, username, avatar, robohash FROM users ORDER BY exp DESC LIMIT $limit");
				
				while($top_user = $fetch_topusers->fetch_assoc()){
					if($start == 1){
						$award = "<span class='diamond'><i class='fa fa-trophy'></i> ".$lang["leaderboard_diamond"]."</span>";
					} else if($start == 2){
						$award = "<span class='gold'><i class='fa fa-trophy'></i> ".$lang["leaderboard_gold"]."</span>";
					} else if($start == 3){
						$award = "<span class='silver'><i class='fa fa-trophy'></i> ".$lang["leaderboard_silver"]."</span>";
					} else if($start == 4){
						$award = "<span class='bronze'><i class='fa fa-trophy'></i> ".$lang["leaderboard_bronze"]."</span>";
					} else {
						$award = NULL;
					}					
					if(!empty($top_user["avatar"])){
						$avatar = '<img src="'.$get->system("site_url").'/templates/'.$get->system("template").'/assets/images/loader.gif" data-src="'.$get->system("site_url").'/uploads/avatars/'.$top_user["avatar"].'" class="lazy-avatar b-radius avatar-img">';						
					} else {
						$avatar = $get->avatar($secure->hashed($top_user["id"]), $top_user["username"], $top_user["robohash"], $get->system("default_avatar"), "avatar-img", $get);
					} 					
					 					
					echo '<div class="col-md-3 pro-1 wow fadeInUp">
								<div class="col-m col-users text-center">
								<a href="'.$get->system("site_url")."/user/".$top_user["username"].'">
										'.$avatar.'
									</a>
									<div class="mid-1">
											<h6 class="uc top_users"><i class="fa fa-user"></i> <a href="'.$get->system("site_url")."/user/".$top_user["username"].'">'.$sys->limitString($top_user["username"], 10).'</a></h6>					 									
											<h6 class="uc top_users award">'.$award.'</h6>		 		
									</div>
								</div>
							</div>';
							
							$start++;
							}					
							?>
						
<div class="clearfix"></div>
	</div>