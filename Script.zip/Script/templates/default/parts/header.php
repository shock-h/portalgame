			<div class="logo">
				<h1><a href="<?php echo $get->system('site_url'); ?>">
				<div class="site-name animated bounce">
				<?php if($get->system("logo") !== ""){ ?>
				<img src="<?php echo $get->system('site_url').'/uploads/'.$get->system('logo'); ?>">
				<?php } else { ?>
				<?php echo $get->system('site_name'); ?>
				<?php } ?>
				</div>
				<span class="animated zoomIn"><?php echo $lang["logo_intro"]; ?></span>
				</a></h1>
			</div>
			
			<?php if (!$check->isLogged()) { ?>
			<div class="head-t">
				<ul class="card">
					<li><a href="<?php echo $get->system('site_url'); ?>/login"><i class="fa fa-user"></i><?php echo $lang["login_link"]; ?></a></li>
					<li><a href="<?php echo $get->system('site_url'); ?>/register"><i class="fa fa-edit"></i><?php echo $lang["register_link"]; ?></a></li>
				</ul>	
			</div>
			<?php if($get->system("fb_id") !== "" && $get->system("fb_secret") !== "" OR $get->system("gp_id") !== "" && $get->system("gp_secret") !== "" OR $get->system("tw_id") !== "" && $get->system("tw_secret") !== ""){ ?>
			<div class="header-ri animated swing">
				<ul class="social-top">				
					<?php if($get->system("fb_id") !== "" && $get->system("fb_secret") !== ""){ ?>
					<li><a href="<?php echo $get->system('site_url'); ?>/login/facebook" class="icon facebook"><i class="fa fa-facebook"></i><span></span></a></li>
					<?php } ?>
					<?php if($get->system("gp_id") !== "" && $get->system("gp_secret") !== ""){ ?> 
					<li><a href="<?php echo $get->system('site_url'); ?>/login/google" class="icon google"><i class="fa fa-google"></i><span></span></a></li>
					<?php } ?> 					
					<?php if($get->system("tw_id") !== "" && $get->system("tw_secret") !== ""){ ?> 		
					<li><a href="<?php echo $get->system('site_url'); ?>/login/twitter" class="icon twitter"><i class="fa fa-twitter"></i><span></span></a></li> 					
					<?php } ?> 					
				</ul>	
			</div> 		
			<?php } ?>
			<?php } else { ?>
			<div class="head-t logged-t">
				<ul class="card">
				 <?php if ($check->isAdmin() OR $check->isModerator()) { ?>
				  <li><a href="<?php echo $get->system('site_url'); ?>/panel"><i class="fa fa-cogs"></i><?php echo $lang["profile_panel_btn"]; ?></a></li>
				  <li><a href="<?php echo $get->system('site_url'); ?>/pending"><i class="fa fa-clock-o"></i><?php echo $lang["profile_pending_btn"]; ?></a></li> 
       <?php } ?> 				
       <?php if($get->system("submissions") == 1){ ?>
					<li><a href="<?php echo $get->system('site_url'); ?>/game/new"><i class="fa fa-edit"></i><?php echo $lang["profile_submit_btn"]; ?></a></li>
				 <?php } ?>
       <?php if($get->system("submissions") == 0 && in_array($user["position"], array(1, 2))){ ?>
					<li><a href="<?php echo $get->system('site_url'); ?>/game/new"><i class="fa fa-edit"></i><?php echo $lang["profile_submit_btn"]; ?></a></li>
				 <?php } ?> 				 
				</ul>	
			</div>
			<?php } ?>				