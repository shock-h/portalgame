<?php
$game = $get->game($data["gid"], $get->system("smart_cache"));
$get_cat = $db->query("SELECT name FROM categories WHERE id = " . $game["category"] . " LIMIT 1");
$cat_data = $get_cat->fetch_assoc();
?>
<div class="header">
    <?php require 'templates/'.$get->system("template").'/parts/header.php'; ?>

    <div class="nav-top">
        <div class="container">
            <nav class="navbar navbar-default">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#nav-main">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>

                <?php require 'templates/'.$get->system("template").'/parts/nav.php'; ?>

            </nav>

            <?php require 'templates/'.$get->system("template").'/parts/nav_profile.php'; ?>

        </div>
    </div>
</div>

<div class="container wrapper">
	<div class="banner-top animated bounceIn">
		<?php if($check->isMobile()){ ?>
		<h3><?php echo $sys->limitString($game["name"], 20); ?></h3>
		<?php } else { ?>
		<h3><?php echo $game["name"]; ?></h3>
		<?php } ?> 		
		<h4><a href="<?php echo $get->system('site_url'); ?>"><?php echo $lang["breadcrumb_home"]; ?></a><label>/</label><?php echo ucfirst($cat_data["name"]); ?></h4>
	</div>
	
	<?php if($get->system("widget_banner_top") !== ""){ ?>
    <?php require 'templates/'.$get->system("template").'/parts/banner_top.php'; ?>
	<?php } ?>
	
	<?php require 'templates/'.$get->system("template").'/parts/play.php'; ?>

	<?php if($get->system("widget_banner_bottom") !== ""){ ?>
    <?php require 'templates/'.$get->system("template").'/parts/banner_bottom.php'; ?>
	<?php } ?>
</div>